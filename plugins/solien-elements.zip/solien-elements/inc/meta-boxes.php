<?php

/* ----------------------------------------------------- 
 * Post Slides Metabox
 * ----------------------------------------------------- */
add_filter( 'rwmb_meta_boxes', 'asw_register_meta_boxes' );
function asw_register_meta_boxes($meta_boxes) {
    $prefix = 'asw_';
	/* ----------------------------------------------------- */
	// Post Slides Metabox
	/* ----------------------------------------------------- */
	$meta_boxes[] = array(
		'id'		=> 'post_layout',
		'title'		=> esc_html__('Post Layout','solien'),
		'pages'		=> array( 'post' ),
		'context' => 'normal',
		'fields'	=> array(
			array(
	    	   'name' => esc_html__('Single post layout', 'solien'),
	    	   'desc' => esc_html__('Select layout type.', 'solien'),
	    	   'id' => $prefix . 'post_layout',
	    	   'type' => 'select',
	    	   'options'  => array(
	    	   		'default' => esc_html__('Default', 'solien'),
	    	   		'wide' => esc_html__('Wide image', 'solien'),
	    	   		'fullwidth' => esc_html__('Fullwidth image', 'solien')
	    	   	),
			   'std' => array('default')
	    	),
	    	array(
			    'name' => esc_html__('Post sidebar', 'solien'),
			    'desc' => esc_html__('Select sidebar position.', 'solien'),
			    'id'   => $prefix . 'post_sidebar',
			    'type' => 'select',
			    'options' => array(
			    	'default' => esc_html__('Default', 'solien'),
			    	'sidebar-right' => esc_html__('Sidebar right', 'solien'),
			    	'sidebar-left' => esc_html__('Sidebar left', 'solien'),
			    	'none' => esc_html__('No sidebar', 'solien'),
			    ),
			    'std'  => array('default'),
			),

		)
	);
	$meta_boxes[] = array(
		'id'		=> 'post_slides',
		'title'		=> esc_html__('Post Gallery','solien'),
		'pages'		=> array( 'post' ),
		'context' => 'normal',
		'fields'	=> array(
			array(
				'name'	=> esc_html__('Post Gallery Images','solien'),
				'desc'	=> esc_html__('Upload up to 30 project images for a slideshow - or only one to display a single image.','solien'),
				'id'	=> $prefix . 'gallery_images',
				'type'	=> 'image_advanced',
				'max_file_uploads' => 30
			),
			array(
	    	   'name' => esc_html__('Gallery layout', 'solien'),
	    	   'desc' => esc_html__('Select gallery layout type.', 'solien'),
	    	   'id' => $prefix . 'gallery_layout',
	    	   'type' => 'switch',
	    	   'on_label'  => esc_html__('Carousel','solien'),
			   'off_label' => esc_html__('Masonry Grid', 'solien'),
	    	),

		)
	);
	$meta_boxes[] = array(
		'id' => $prefix . 'post_header',
		'title' =>  esc_html__('Post meta', 'solien'),
		'pages' 	=> array('post'),
		'context' 	=> 'normal',
		'fields' 	=> array(
	    	array(
	    	   'name' => esc_html__('Display header?', 'solien'),
	    	   'desc' => esc_html__('Select show or hide post header meta.', 'solien'),
	    	   'id' => $prefix . 'display_post_header',
	    	   'type' => 'switch',
	    	   'on_label'  => esc_html__('Hide','solien'),
			    // Off label
			    'off_label' => esc_html__('Show', 'solien'),
	    	),
	    	array(
	    	   'name' => esc_html__('Display footer?', 'solien'),
	    	   'desc' => esc_html__('Select show or hide post footer meta.', 'solien'),
	    	   'id' => $prefix . 'display_post_footer',
	    	   'type' => 'switch',
	    	   'on_label'  => esc_html__('Hide','solien'),
			    // Off label
			    'off_label' => esc_html__('Show', 'solien'),
	    	)
		)
	);
	return $meta_boxes;
}
