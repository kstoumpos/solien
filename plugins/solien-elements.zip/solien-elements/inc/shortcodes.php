<?php
if( !function_exists('SolienPostSlider') ){
	function SolienPostSlider($atts, $content = null){
		wp_enqueue_script('owl-carousel');
		wp_enqueue_style( 'owl-carousel' );
	    extract(shortcode_atts(array(
	    	'slideshow' => true,
	      	'number_posts' => '3',
	      	'orderby' => 'date',
	      	'order' => 'DESC',
	      	'thumbsize' => 'large',
	      	'cat_slug' => '',
	      	'post_ids' => '',
	      	'style' => '',
	      	'slider_width' => 'standard'
	    ), $atts));

	    global $post;
		if ( is_front_page() ) {
			$paged = (get_query_var('page')) ? get_query_var('page') : 1;
		} else {
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		}
		if($post_ids != ''){
			$post_ids = str_replace(' ', '', $post_ids);
			$post_ids = explode(',', $post_ids);
		} else {
			$post_ids = array();
		}
		$args = array(
			'post_type' => 'post',
			'posts_per_page' => $number_posts,
			'post__in' => $post_ids,
			//'paged' => $paged,
			'order'          => $order,
			'orderby'        => $orderby,
			'post_status'    => 'publish',
			'ignore_sticky_posts' => true,
			'meta_query' => array(
		        array(
		         'key' => '_thumbnail_id',
		         'compare' => 'EXISTS'
		        ),
		    )
		);

		if($cat_slug != '' && $cat_slug != 'all'){
			$str = $cat_slug;
			$arr = explode(',', $str);	  
			$args['tax_query'][] = array(
			  'taxonomy'  => 'category',
			  'field'   => 'slug',
			  'terms'   => $arr
			);
		}
		if( $style == 'center' ){
			$center = $loop = 'true';
			$items = '2';
			$margin = '10';
			$centerClass = 'post-slider-center';
		} elseif ($style == 'three_per_row') {
			$center = 'false';
			$loop = 'true';
			$items = '3';
			$margin = '10';
			$centerClass = 'slider-three-per-row';
		} else {
			$center = $loop = 'false';
			$items = '1';
			$centerClass = '';
			$margin = '0';
		}
		static $slider_id = 0;
		$out = '';
		query_posts( $args );
		if( have_posts() ) {
			if(is_rtl()){
				$rtl = 'rtl: true,';
			} else {
				$rtl = '';
			}
			$owl_custom = 'jQuery(document).ready(function($){
				"use strict";
				setTimeout(function(){var owl = $("#post-slider-'.++$slider_id.'").owlCarousel(
				    {
				    	'.$rtl.'
				        items: '.$items.',
				        center: '.$center.',
				        margin: '.$margin.',
				        dots: false,
				        nav: true,
				        navText: [\'<i class="la la-angle-left"></i>\',\'<i class="la la-angle-right"></i>\'],
				        autoplay: '.$slideshow.',
				        responsiveClass:true,
				        loop: '.$loop.',
				        smartSpeed: 450,
				        autoHeight: false,
				        autoWidth:'.$center.',
				        themeClass: "owl-post-slider",';
				    if($style == 'three_per_row'){
				    	$owl_custom .= 'responsive:{
				            0:{
				                items:1,
				            },
				            782:{
				                items:2,
				            },
				            960:{
				                items:3
				            }
				        }';
				    }
				    $owl_custom .= '});
			}, 10);
				
			});';
			wp_add_inline_script('owl-carousel', $owl_custom);
			$out .= '<div id="post-slider-'.$slider_id.'" class="owl-carousel post-slider '.$centerClass.' '.$slider_width.'">';
			while ( have_posts() ) {
				the_post();
				$out .= '<div class="post-slider-item">';
					if( has_post_thumbnail() ) {
						$out .= '<figure class="post-img"><a href="'.esc_url(get_the_permalink()).'" rel="bookmark">'.get_the_post_thumbnail($post->ID, $thumbsize).'</a></figure>';
					}
					$out .= '<div class="post-more">';
					$out .= '<div class="post-more-inner">';
						$out .= '<h3><a href="'.get_the_permalink().'" title="'.esc_html__('Permalink to', 'solien-elements').' '.esc_attr(the_title_attribute('echo=0')).'" rel="bookmark">'.esc_attr(get_the_title()).'</a></h3>';
						$out .= '<div class="read-more-hover"><div class="meta-date"><span>'.__('Posted by', 'solien-elements').' '.get_the_author().' </span><time datetime="'.date(DATE_W3C).'">'.__('On', 'solien-elements').' '.get_the_time(get_option('date_format')).'</time></div>';
						$out .= '<a href="'.esc_url(get_the_permalink()).'" class="post-more-link" title="'.esc_html__('Permalink to', 'solien-elements').' '.esc_attr(the_title_attribute('echo=0')).'" rel="bookmark">'.esc_html__('Read more', 'solien-elements').'</a></div>';
					$out .= '</div>';
					$out .= '</div>';
				$out .= '</div>';
			}
			$out .= '</div>';
		}
		wp_reset_query();
		return $out;
	}
	add_shortcode('post_slider', 'SolienPostSlider');
}
if( !function_exists('SolienGridPosts') ){
	function SolienGridPosts($atts, $content = null){
	    extract(shortcode_atts(array(
	      	'number_posts' => '3',
	      	'block_title' => '',
	      	'columns' => 'span4',
	      	'orderby' => 'date',
	      	'order' => 'DESC',
	      	'cat_slug' => '',
	      	'post_ids' => '',
	      	'thumbSize' => 'medium'
	    ), $atts));

	    global $post;
		if ( is_front_page() ) {
			$paged = (get_query_var('page')) ? get_query_var('page') : 1;
		} else {
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		}
		if($post_ids != ''){
			$post_ids = str_replace(' ', '', $post_ids);
			$post_ids = explode(',', $post_ids);
		} else {
			$post_ids = array();
		}
		$args = array(
			'post_type' => 'post',
			'posts_per_page' => $number_posts,
			'post__in' => $post_ids,
			'paged' => $paged,
			'order'          => $order,
			'orderby'        => $orderby,
			'post_status'    => 'publish',
			'ignore_sticky_posts' => true
		);

		if($cat_slug != '' && $cat_slug != 'all'){
			$str = $cat_slug;
			$arr = explode(',', $str);	  
			$args['tax_query'][] = array(
			  'taxonomy'  => 'category',
			  'field'   => 'slug',
			  'terms'   => $arr
			);
		}
		static $post_section_id = 0;
		$out = '';
		++$post_section_id;
		query_posts( $args );
		if( have_posts() ) {
			if($block_title != ''){
				$out .= '<div class="block-title title"><h3>'.esc_html($block_title).'</h3></div>'; 
			}
			$out .= '<div id="recent-posts-'.$post_section_id.'" class="recent-posts">';
			while ( have_posts() ) {
				the_post();
				$out .= '<div class="recent-post-item '.$columns.'">';
					if( has_post_thumbnail() ) {
						$out .= '<figure class="post-img"><a href="'.esc_url(get_the_permalink()).'" rel="bookmark">'.get_the_post_thumbnail($post->ID, $thumbSize).'</a></figure>';
					} else {
						$out .= '<figure class="post-img"><a href="'.esc_url(get_the_permalink()).'" rel="bookmark"><img src="https://placeholdit.imgix.net/~text?txtsize=42&txt=Your+image+here&w=470&h=410" alt="placeholder image"></a></figure>';
					}
					$out .= '<div class="post-more">';
						$out .= '<div class="title"><h3><a href="'.esc_url(get_the_permalink()).'" title="'.esc_html__('Permalink to', 'solien-elements').' '.esc_attr(the_title_attribute('echo=0')).'" rel="bookmark">'.esc_attr(get_the_title()).'</a></h3></div>';
						$out .= '<div class="meta-date"><time datetime="'.esc_attr(date(DATE_W3C)).'">'.get_the_time(get_option('date_format')).'</time></div>';
					$out .= '</div>';
				$out .= '</div>';
			}
			$out .= '</div>';
		}
		wp_reset_query();
		return $out;
	}
	add_shortcode('gridposts', 'SolienGridPosts');
}
if( !function_exists('SolienCarouselPosts') ){
	function SolienCarouselPosts($atts, $content = null){
		wp_enqueue_script('owl-carousel');
		wp_enqueue_style( 'owl-carousel' );
	    extract(shortcode_atts(array(
	      	'block_title' => '',
	      	'posts_count' => '3',
	      	'columns' => 'span4',
	      	'orderby' => 'date',
	      	'order' => 'DESC',
	      	'cat_slug' => '',
	      	'post_ids' => '',
	      	'thumbsize' => 'medium'
	    ), $atts));

	    global $post;
		if ( is_front_page() ) {
			$paged = (get_query_var('page')) ? get_query_var('page') : 1;
		} else {
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		}
		if($post_ids != ''){
			$post_ids = str_replace(' ', '', $post_ids);
			$post_ids = explode(',', $post_ids);
		} else {
			$post_ids = array();
		}
		$args = array(
			'post_type' => 'post',
			'posts_per_page' => $posts_count,
			'post__in' => $post_ids,
			//'paged' => $paged,
			'order'          => $order,
			'orderby'        => $orderby,
			'post_status'    => 'publish',
			'ignore_sticky_posts' => true
		);

		if($cat_slug != '' && $cat_slug != 'all'){
			$str = $cat_slug;
			$arr = explode(',', $str);	  
			$args['tax_query'][] = array(
			  'taxonomy'  => 'category',
			  'field'   => 'slug',
			  'terms'   => $arr
			);
		}
		switch ($columns) {
			case 'span6':
				$items = '2';
				break;
			case 'span4':
				$items = '3';
				break;
			case 'span3':
				$items = '4';
				break;
			case 'span2':
				$items = '6';
				break;
			default:
				$items = '5';
				break;
		}
		static $post_section_id = 0;
		$out = '';
		++$post_section_id;
		query_posts( $args );
		if( have_posts() ) {
			if($posts_count > $items){
				if(is_rtl()){
					$rtl = 'rtl: true,';
				} else {
					$rtl = '';
				}
				$columns = '';
				$owl_custom = 'jQuery(document).ready(function($){
					"use strict";
					setTimeout(function(){ var owl = $("#recent-posts-slider-'.$post_section_id.'").owlCarousel(
				    {
				    	'.$rtl.'
				        items: '.$items.',
				        margin: 0,
				        dots: false,
				        nav: false,
				        autoplay: true,
				        responsiveClass:true,
				        loop: false,
				        smartSpeed: 450,
				        autoHeight: false,';
					    $owl_custom .= '});
						$(window).load(function(){
							owl.trigger(\'refresh.owl.carousel\');
						});
					}, 10);
				});';
				wp_add_inline_script('owl-carousel', $owl_custom);
			}
			if($block_title != ''){
				$out .= '<div class="block-title title"><h3>'.esc_html($block_title).'</h3></div>'; 
			}
			$out .= '<div id="recent-posts-slider-'.$post_section_id.'" class="recent-posts">';
			while ( have_posts() ) {
				the_post();
				$out .= '<div class="recent-post-item '.$columns.'">';
					if( has_post_thumbnail() ) {
						$out .= '<figure class="post-img"><a href="'.esc_url(get_the_permalink()).'" rel="bookmark">'.get_the_post_thumbnail($post->ID, $thumbsize).'</a></figure>';
					} else {
						$out .= '<figure class="post-img"><a href="'.esc_url(get_the_permalink()).'" rel="bookmark"><img src="https://placeholdit.imgix.net/~text?txtsize=42&txt=Your+image+here&w=470&h=390" alt="placeholder image"></a></figure>';
					}
					$out .= '<div class="post-more">';
						$out .= '<div class="title"><h3><a href="'.esc_url(get_the_permalink()).'" title="'.esc_html__('Permalink to', 'solien-elements').' '.esc_attr(the_title_attribute('echo=0')).'" rel="bookmark">'.esc_attr(get_the_title()).'</a></h3></div>';
						$out .= '<div class="meta-date"><time datetime="'.esc_attr(date(DATE_W3C)).'">'.get_the_time(get_option('date_format')).'</time></div>';
					$out .= '</div>';
				$out .= '</div>';
			}
			$out .= '</div>';
			wp_reset_query();
		}
		return $out;
	}
	add_shortcode('carouselposts', 'SolienCarouselPosts');
}
if( !function_exists('SolienRecentPosts') ){
	function SolienRecentPosts($atts, $content = null){
		wp_enqueue_script('isotope');
	    extract(shortcode_atts(array(
	      	'num' => '5',
	      	'orderby' => 'date',
	      	'order' => 'DESC',
	      	'cat_slug' => '',
	      	'post_ids' => '',
	      	'pagination' => 'false',
	      	'thumbsize'		=> 'post-thumbnail',
	      	'ignore_sticky_posts' => 'false'
	    ), $atts));

	    global $post;
	    global $paged;

		if ( is_front_page() ) {
			$paged = (get_query_var('page')) ? get_query_var('page') : 1;
		} else {
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		}

		if($post_ids != ''){
			$post_ids = str_replace(' ', '', $post_ids);
			if (strpos($post_ids, ',') !== false){
				$post_ids = explode(',', $post_ids);
			} else {
				$post_ids = array($post_ids);
			}
		} else {
			$post_ids = array();
		}
		$ignore_sticky_posts = ($ignore_sticky_posts === 'true');
		$args = array(
			'post_type' => 'post',
			'posts_per_page' => $num,
			'post__in' => $post_ids,
			'paged' => $paged,
			'order'          => $order,
			'orderby'        => $orderby,
			'post_status'    => 'publish',	
			'ignore_sticky_posts' => $ignore_sticky_posts
		);
		if($cat_slug != '' && $cat_slug != 'all'){
			$str = str_replace(' ', '', $cat_slug);
			$arr = explode(',', $str);	  
			$args['tax_query'][] = array(
			  'taxonomy'  => 'category',
			  'field'   => 'slug',
			  'terms'   => $arr
			);
			$ignore_sticky_posts = true;
		}

		static $post_section_id = 0;
		$out = '';
		++$post_section_id;
		query_posts( $args );
		if( have_posts() ) {
			$out .= '<div id="latest-posts" class="row">';
			while ( have_posts() ) {
				the_post();
				$tmpContent = get_the_content();
				$classes = join(' ', get_post_class($post->ID));
				$separator = '';
				if (get_theme_mod( 'asw_posts_headings_separator', true ) ) $separator = ' separator';
				$out .= '<article itemscope itemtype="http://schema.org/Article" class="'.$classes.'">';
					$out .= '<div class="post-content-container aligncenter">';
					if( !rwmb_meta( 'asw_display_post_header') ){
						$out .= '<div class="meta-categories">'.get_the_category_list(', ').'</div>';
						$out .= '<header class="title">';
						$out .= '<h2 itemprop="headline"><a href="'.get_the_permalink().'" title="'.esc_html__('Permalink to', 'solien-elements').' '.esc_attr(the_title_attribute('echo=0')).'" rel="bookmark">'.get_the_title().'</a></h2>';
						$out .= '</header>';
						$out .= '<div class="meta-date'.$separator.'"><span>'.esc_html__('Posted by', 'solien-elements').' '.get_the_author().'</span><time datetime="'.date(DATE_W3C).'">'.esc_html__('On', 'solien-elements').' '.get_the_time(get_option('date_format')).'</time></div>';
					}
					$out .= '<div class="post-content">';
						$images = rwmb_meta( 'asw_gallery_images', 'type=image&size=large');
						if(!empty($images) && !solien_post_has_more_link( get_the_ID() )){
							$out .= '<div class="gallery-block">';
							$i=1;
							foreach( $images as $image ) :  
								if($i > 2) break;
								if( $i == 2 ) {
									$img_id = $image['ID'];
									$tmp_image = wp_get_attachment_image_src($img_id, 'masonry', false);
									$image_url = $tmp_image[0];
								} else {
									$image_url = $image['url']; 
								}
								
								$out .= '<div class="gallery-image-'.$i.'"><a href="'.esc_url($image['full_url']).'" rel="lightbox-gallery" data-caption="'.esc_attr($image['caption']).'"><img src="'.esc_url($image_url).'" alt="'.esc_attr($image['alt']).'" /></a></div>';
							$i++; endforeach;
							$out .= '</div>';
						} elseif( has_post_thumbnail() && !solien_post_has_more_link( get_the_ID() ) ) {
							$out .= '<figure class="post-img"><a href="'.esc_url(get_the_permalink()).'" rel="bookmark"><img src="'.get_the_post_thumbnail_url($post->ID, $thumbsize).'" alt="'.get_the_title().'" ></a></figure>';
						}
						if( solien_post_has_more_link( get_the_ID() ) ){
							$out .= '<div class="post-excerpt">'.solien_get_the_content().'</div>';
						} else {
							$out .= '<div class="post-excerpt">'.get_the_excerpt().'</div>';
						}
						$out .= wp_link_pages(array('before' =>'<div class="pagination_post">', 'after'  =>'</div>', 'pagelink' => '<span>%</span>', 'echo' => 0));
						$out .= '</div>';
						if( !rwmb_meta( 'asw_display_post_footer') ){
							$out .= '<div class="post-meta">';
								if ( comments_open() ) :
									$out .= '<span class="meta meta-comment">';
										$out .= SolienCommentsNumber( get_the_ID() );
									$out .='</span>';
								endif;
								$out .= '<div class="post-more post-more-arrow"><a href="'.esc_url(get_the_permalink()).'" rel="bookmark"><i class="la la-angle-right icon1"></i><i class="la la-long-arrow-right icon2"></i></a></div>';
								$out .= SolienSharebox( get_the_ID() );
							$out .= '</div>';
						}
					$out .= '</div>';
				$out .= '</article>';
			}
			$out .= '</div>';
		}
		if( $pagination == 'true' ) {
			if(solien_custom_pagination() != '') {
				$out .= '<div id="pagination" class="clearfix">'.solien_custom_pagination().'</div>';
			}
		}
		wp_reset_query();
		return $out;
	}
	add_shortcode('recentposts', 'SolienRecentPosts');
}
if( !function_exists('SolienListPosts') ){
	function SolienListPosts($atts, $content = null){
		wp_enqueue_script('isotope');
		extract(shortcode_atts(array(
	      	'num' => '6',
	      	'orderby' => 'date',
	      	'order' => 'DESC',
	      	'cat_slug' => '',
	      	'post_ids' => '',
	      	'pagination' => 'false',
	      	'thumbsize'		=> 'post-thumbnail',
	      	'text_align' => '',
	      	'excerpt_count'	=> '32',
	      	'ignore_sticky_posts' => 'false'
	    ), $atts));

	    global $post;
		if ( is_front_page() ) {
			$paged = (get_query_var('page')) ? get_query_var('page') : 1;
		} else {
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		}
		if($post_ids != ''){
			$post_ids = str_replace(' ', '', $post_ids);
			if (strpos($post_ids, ',') !== false){
				$post_ids = explode(',', $post_ids);
			} else {
				$post_ids = array($post_ids);
			}
		} else {
			$post_ids = array();
		}
		$ignore_sticky_posts = ($ignore_sticky_posts === 'true');
		$args = array(
			'post_type' => 'post',
			'posts_per_page' => $num,
			'post__in' => $post_ids,
			'paged' => $paged,
			'order'          => $order,
			'orderby'        => $orderby,
			'post_status'    => 'publish',	
			'ignore_sticky_posts' => $ignore_sticky_posts
		);
		if($cat_slug != '' && $cat_slug != 'all'){
			$str = str_replace(' ', '', $cat_slug);
			$arr = explode(',', $str);	  
			$args['tax_query'][] = array(
			  'taxonomy'  => 'category',
			  'field'   => 'slug',
			  'terms'   => $arr
			);
			$ignore_sticky_posts = true;
		}

		if($paged != 1) {

			$ignore_sticky_posts = true;
			$offset = $num + (($paged - 2) * 4);
            $args = array(
            	'posts_per_page' => 4,
            	'offset' => $offset,
            	'ignore_sticky_posts' => $ignore_sticky_posts
            );
		}
	
		static $post_section_id = 0;
		$out = '';
		++$post_section_id;
		query_posts( $args );
		if( have_posts() ) {
			$out .= '<div id="latest-posts">';
			$out .= '<div id="blog-posts-'.$post_section_id.'" class="row-fluid blog-posts">';
			while ( have_posts() ) {
				the_post();
				$tmpContent = get_the_content();
				$separator = '';
				if (get_theme_mod( 'asw_posts_headings_separator', true ) ) $separator = ' separator';
				$classes = join(' ', get_post_class($post->ID));
				if(!$ignore_sticky_posts && is_sticky()){
					$out .= '<article itemscope itemtype="http://schema.org/Article" class="span12 '.$classes.'">';
						$out .= '<div class="post-content-container aligncenter">';
						if( !rwmb_meta( 'asw_display_post_header') ){
							$out .= '<div class="meta-categories">'.get_the_category_list(', ').'</div>';
							$out .= '<header class="title">';
							$out .= '<h2 itemprop="headline"><a href="'.get_the_permalink().'" title="'.esc_html__('Permalink to', 'solien-elements').' '.esc_attr(the_title_attribute('echo=0')).'" rel="bookmark">'.get_the_title().'</a></h2>';
							$out .= '</header>';
							$out .= '<div class="meta-date'.$separator.'"><span>'.esc_html__('Posted by', 'solien-elements').' '.get_the_author().'</span><time datetime="'.date(DATE_W3C).'">'.esc_html__('On', 'solien-elements').' '.get_the_time(get_option('date_format')).'</time></div>';
						}
						$out .= '<div class="post-content">';
							$images = rwmb_meta( 'asw_gallery_images', 'type=image&size=large');
							if(!empty($images) && !solien_post_has_more_link( get_the_ID() )){
								$out .= '<div class="gallery-block">';
								$i=1;
								foreach( $images as $image ) :  
									if($i > 2) break;
									if( $i == 2 ) {
										$img_id = $image['ID'];
										$tmp_image = wp_get_attachment_image_src($img_id, 'masonry', false);
										$image_url = $tmp_image[0];
									} else {
										$image_url = $image['url']; 
									}
									$out .= '<div class="gallery-image-'.$i.'"><a href="'.esc_url($image['full_url']).'" data-lightbox="lightbox-gallery" data-caption="'.esc_attr($image['caption']).'"><img src="'.esc_url($image_url).'" alt="'.esc_attr($image['alt']).'" /></a></div>';
								$i++; endforeach;
								$out .= '</div>';
							} elseif( has_post_thumbnail() && !solien_post_has_more_link( get_the_ID() ) ) {
								$out .= '<figure class="post-img"><a href="'.esc_url(get_the_permalink()).'" rel="bookmark">'.get_the_post_thumbnail($post->ID, 'large').'</a></figure>';
							}
							if( solien_post_has_more_link( get_the_ID() ) ){
								$out .= '<div class="post-excerpt">'.solien_get_the_content().'</div>';
							} else {
								$out .= '<div class="post-excerpt">'.get_the_excerpt().'</div>';
							}
							$out .= wp_link_pages(array('before' =>'<div class="pagination_post">', 'after'  =>'</div>', 'pagelink' => '<span>%</span>', 'echo' => 0));
							$out .= '</div>';
							if( !rwmb_meta( 'asw_display_post_footer') ){
								$out .= '<div class="post-meta">';
									$out .= SolienSharebox( get_the_ID() );
									if ( comments_open() ) :
										$out .= '<span class="meta meta-comment">';
											$out .= SolienCommentsNumber( get_the_ID() );
										$out .='</span>';
									endif;
									$out .= '<div class="post-more post-more-arrow"><a href="'.esc_url(get_the_permalink()).'" rel="bookmark"><i class="la la-angle-right icon1"></i><i class="la la-long-arrow-right icon2"></i></a></div>';
								$out .= '</div>';
							}
						$out .= '</div>';
					$out .= '</article>';
				} else {
					$out .= '<article itemscope itemtype="http://schema.org/Article" class="span6 '.$classes.'">';
						$out .= '<div class="post-content-container aligncenter">';
							if( has_post_thumbnail() ) {
								$out .= '<figure class="post-img"><a href="'.esc_url(get_the_permalink()).'" rel="bookmark">'.get_the_post_thumbnail($post->ID, $thumbsize).'</a></figure>';
							}
							$out .= '<div class="meta-categories">'.get_the_category_list(', ').'</div>';
							$out .= '<header class="title">';
							$out .= '<h2 itemprop="headline"><a href="'.get_the_permalink().'" title="'.esc_html__('Permalink to', 'solien-elements').' '.esc_attr(the_title_attribute('echo=0')).'" rel="bookmark">'.get_the_title().'</a></h2>';
							$out .= '</header>';
							$out .= '<div class="meta-date'.$separator.'"><span>'.esc_html__('Posted by', 'solien-elements').' '.get_the_author().'</span><time datetime="'.date(DATE_W3C).'">'.esc_html__('On', 'solien-elements').' '.get_the_time(get_option('date_format')).'</time></div>';
							$out .= '<div class="post-content">';
							if( solien_post_has_more_link( get_the_ID() ) ){
								$out .= '<div class="post-excerpt">'.solien_get_the_content().'</div>';
							} else {
								$out .= '<div class="post-excerpt">'.SolienExcerpt($excerpt_count).'</div>';
							}
								$out .= wp_link_pages(array('before' =>'<div class="pagination_post">', 'after'  =>'</div>', 'pagelink' => '<span>%</span>', 'echo' => 0));
							$out .= '</div>';
							$out .= '<div class="aligncenter"><a href="'.get_the_permalink().'" class="readmore-icon" title="'.esc_html__('Permalink to', 'solien-elements').' '.esc_attr(the_title_attribute('echo=0')).'" rel="bookmark"><i class="la la-long-arrow-right"></i></a></div>';
						$out .= '</div>';
					$out .= '</article>';
				}
			}
			$out .= '</div>';
		}
		if( $pagination == 'true' ) {
			$custom = 'jQuery( document ).ready( function($) { $(window).load(function(){ $(window).unbind(\'.infscr\'); }); });';
			wp_add_inline_script('solien-functions', $custom);
			$out .= '<div id="pagination" class="hide">'.get_next_posts_link().'</div>';
			$out .= '<div class="loadmore-container"><a href="#" class="loadmore"><span>'.esc_html__('Load More','Solien').'</span></a></div>';
		}
		$out .= '</div>';
		wp_reset_query();
		return $out;
	}
	add_shortcode('listposts', 'SolienListPosts');
}
if( !function_exists('SolienAuthorInfo') ){
	function SolienAuthorInfo( $atts, $content = null){
		extract(
			shortcode_atts( array(
				'username' => ''
				), $atts
			)
		);
		global $post;
		$out = '';
		if( $username == '' ){
			$userID = get_current_user_id();
		} else {
			$userInfo = get_user_by('login', $username);
			$userID = $userInfo->ID;
		}
		// retrieve our additional author meta info
		$user_meta_image = esc_attr( get_the_author_meta( 'user_meta_image', $userID ) );
		// make sure the field is set
		if ( isset( $user_meta_image ) && $user_meta_image ) {
		    // only display if function exists
		    if ( function_exists( 'asw_framework_get_additional_user_meta_thumb' ) )
		        $userImage = '<img alt="'.esc_html__('author photo', 'solien-elements').'" src="'.esc_url(asw_framework_get_additional_user_meta_thumb($userID, 'medium')).'" />';
		} else {
			$userImage = '<img alt="'.esc_html__('author photo', 'solien-elements').'" src="https://placeholdit.imgix.net/~text?txtsize=24&txt=User+Image&w=252&h=225&txttrack=0" />';
		}
		$out .= '<div class="author-info-shortcode row-fluid">';
		$out .= '<div class="author-image span4">'.$userImage.'</div>';
		$out .= '<div class="author-description span8">';
		$out .= '<h2 class="author-title ">'.esc_attr(get_the_author_meta( 'first_name', $userID )).' '.esc_attr(get_the_author_meta( 'last_name', $userID )).'</h2>';
		$out .= '<p>'.get_the_author_meta( 'description', $userID ).'</p>';
		$out .= '<div class="author-email"><a href="mailto:'.esc_attr(get_the_author_meta( 'user_email', $userID )).'">'.esc_attr(get_the_author_meta( 'user_email', $userID )).'</a></div>';
		$out .= '</div>';
		$out .= '</div>';

		return $out;
	}
	add_shortcode('solienuser', 'SolienAuthorInfo');
}

if( !function_exists('SolienCTA') ){
	function SolienCTA( $atts, $content = null){
		extract(
			shortcode_atts( array(
				'button_label' => '',
				'button_url' => '#',
				'bg_image_id' => ''
				), $atts
			)
		);

		$imageSrc = wp_get_attachment_image_url($bg_image_id, 'full');
		$out = '<div class="cta-block" style="background-image:url('.esc_url($imageSrc).');">';
		$out .= '<a href="'.esc_url($button_url).'" class="cta-button">'.esc_attr($button_label).'</a>';
		$out .= '</div>';
		return $out;
	}
	add_shortcode('soliencta', 'SolienCTA');
}

if(!function_exists('SolienSocials')){
	function SolienSocials( $atts, $content = null) {
	extract( shortcode_atts( array(
        'twitter'   => '',
        'forrst'  => '',
        'dribbble'  => '',
        'flickr'    => '',
        'facebook'  => '',
        'skype'   => '',
        'digg'  => '',
        'google_plus'  => '',
        'linkedin'  => '',
        'vimeo'  => '',
        'instagram' => '',
        'yahoo'  => '',
        'tumblr'  => '',
        'youtube'  => '',
        'picasa'  => '',
        'deviantart'  => '',
        'behance'  => '',
        'pinterest'  => '',
        'paypal'  => '',
        'delicious'  => '',
        'rss'  => ''
        ), $atts ) );

        $out = '<div class="social-icons aligncenter"><ul class="unstyled">';
		foreach ($atts as $key => $value) {
			switch ($key) {
				case 'twitter':
					if($twitter != "") {
					  $out .= '<li class="social-twitter"><a href="'.esc_url($twitter).'" target="_blank" title="'.esc_html__( 'Twitter', 'solien-elements').'"><i class="fa fa-twitter"></i></a></li>';
					}
					break;
				case 'facebook':
					if($facebook != "") {
					  $out .= '<li class="social-facebook"><a href="'.esc_url($facebook).'" target="_blank" title="'.esc_html__( 'Facebook', 'solien-elements').'"><i class="fa fa-facebook"></i></a></li>';
					}
				case 'forrst':
					if($forrst != "") {
					  $out .= '<li class="social-forrst"><a href="'.esc_url($forrst).'" target="_blank" title="'.esc_html__( 'Forrst', 'solien-elements').'"><i class="fa icon-forrst"></i></a></li>';
					}
					break;
				case 'yahoo':
					if($yahoo != "") {
					  $out .= '<li class="social-yahoo"><a href="'.esc_url($yahoo).'" target="_blank" title="'.esc_html__( 'Yahoo', 'solien-elements').'"><i class="fa fa-yahoo"></i></a></li>';
					}
					break;
				case 'vimeo':
					if($vimeo != "") {
					  $out .= '<li class="social-vimeo"><a href="'.esc_url($vimeo).'" target="_blank" title="'.esc_html__( 'Vimeo', 'solien-elements').'"><i class="fa fa-vimeo-square"></i></a></li>';
					}
					break;
				case 'linkedin':
					if($linkedin != "") {
					  $out .= '<li class="social-linkedin"><a href="'.esc_url($linkedin).'" target="_blank" title="'.esc_html__( 'LinkedIn', 'solien-elements').'"><i class="fa fa-linkedin"></i></a></li>';
					}
					break;
				case 'google_plus':
					if($google_plus != "") {
						$out .= '<li class="social-googleplus"><a href="'.esc_url($google_plus).'" target="_blank" title="'.esc_html__( 'Google plus', 'solien-elements').'"><i class="fa fa-google-plus"></i></a></li>';
					}
					break;
				case 'instagram':
					if($instagram != '') {
						$out .= '<li class="social-instagram"><a href="' .esc_url($instagram). '" target="_blank" title="'.esc_html__( 'Instagram', 'solien-elements').'"><i class="fa fa-instagram"></i></a></li>';
					}
					break;  
				case 'digg':
					if($digg != "") {
						$out .= '<li class="social-digg"><a href="'.esc_url($digg).'" target="_blank" title="'.esc_html__( 'Digg', 'solien-elements').'"><i class="fa fa-digg"></i></a></li>';
					}
					break;
				case 'skype':
					if($skype != "") {
						$out .= '<li class="social-skype"><a href="skype:'.$skype.'?call" title="'.esc_html__( 'Skype', 'solien-elements').'"><i class="fa fa-skype"></i></a></li>';
					}
					break;
				case 'flickr':
					if($flickr != "") { 
						$out .= '<li class="social-flickr"><a href="'.esc_url($flickr).'" target="_blank" title="'.esc_html__( 'Flickr', 'solien-elements').'"><i class="fa fa-flickr"></i></a></li>';
					}
					break;
				case 'dribbble':
					if($dribbble != "") {
						$out .= '<li class="social-dribbble"><a href="'.esc_url($dribbble).'" target="_blank" title="'.esc_html__( 'Dribbble', 'solien-elements').'"><i class="fa fa-dribbble"></i></a></li>';
					}
					break;
				case 'tumblr':
					if($tumblr != "") {
						$out .= '<li class="social-tumblr"><a href="'.esc_url($tumblr).'" target="_blank" title="'.esc_html__( 'Tumblr', 'solien-elements').'"><i class="fa fa-tumblr"></i></a></li>';
					}
				break;
				case 'youtube':
					if($youtube != "") {
						$out .= '<li class="social-youtube"><a href="'.esc_url($youtube).'" target="_blank" title="'.esc_html__( 'YouTube', 'solien-elements').'"><i class="fa fa-youtube"></i></a></li>';
					}
					break;
				case 'picasa':
					if($picasa != "") {
						$out .= '<li class="social-picasa"><a href="'.esc_url($picasa).'" target="_blank" title="'.esc_html__( 'Picasa', 'solien-elements').'"><i class="fa fa-picasa"></i></a></li>';
					}
					break;
				case 'deviantart':
					if($deviantart != "") {
						$out .= '<li class="social-deviantart"><a href="'.esc_url($deviantart).'" target="_blank" title="'.esc_html__( 'DeviantArt', 'solien-elements').'"><i class="fa fa-deviantart"></i></a></li>';
					}
					break;
				case 'behance':
					if($behance != "") {
						$out .= '<li class="social-behance"><a href="'.esc_url($behance).'" target="_blank" title="'.esc_html__( 'Behance', 'solien-elements').'"><i class="fa fa-behance"></i></a></li>';
					}
					break;
				case 'pinterest':
					if($pinterest != "") {
						$out .= '<li class="social-pinterest"><a href="'.esc_url($pinterest).'" target="_blank" title="'.esc_html__( 'Pinterest', 'solien-elements').'"><i class="fa fa-pinterest-p"></i></a></li>';
					}
					break;
				case 'paypal':
					if($paypal != "") {
						$out .= '<li class="social-paypal"><a href="'.esc_url($paypal).'" target="_blank" title="'.esc_html__( 'PayPal', 'solien-elements').'"><i class="fa fa-paypal"></i></a></li>';
					}
					break;
				case 'delicious':
					if($delicious != "") {
						$out .= '<li class="social-delicious"><a href="'.esc_url($delicious).'" target="_blank" title="'.esc_html__( 'Delicious', 'solien-elements').'"><i class="fa fa-delicious"></i></a></li>';
					}
					break;
				case 'rss':
				    if($rss != "") {
				      $out .= '<li class="social-rss"><a href="'.esc_url($rss).'" target="_blank" title="'.esc_html__( 'RSS', 'solien-elements').'"><i class="fa fa-rss"></i></a></li>';
				    }
				    break;
				default:
				# code...
				break;
			}
		}
		$out .= '</ul></div>';
        return $out;
	}
	add_shortcode('soliensocials', 'SolienSocials');
}
if(!function_exists('SolienInstagramPost')){
	function SolienInstagramPost($atts, $content = null) {
		extract( shortcode_atts( array(
	        'media_url' => ''
        ), $atts ) );
        $api = wp_remote_get("http://api.instagram.com/oembed?url=".$media_url);   
		$apiObj = json_decode($api['body'],true);
		if ( !isset($apiObj['author_name']) ) {
	        // error handling
	        $out = esc_html__("Something went wrong: please, check your media url", 'solien-elements');

	    } else {
	    	$author_name = $apiObj['author_name'];
			$author_url = $apiObj['author_url'];
			$matches = explode('/p/', $media_url); 
			$matches = explode('/', $matches[1]);
			$media_id = $matches[0]; 
			if(strlen($media_id) < 9 ) {
				$media_id = 'BN6ni5KA7sj';
			}
	        $out = '<div class="instagram-item-post">
					<a href="'.esc_attr($media_url).'" target="_blank">
						<figure class="image instagram-image">
							<img src="https://instagram.com/p/'.esc_attr($media_id).'/media/?size=l">
						</figure>
					</a>
					<div class="instagram-meta">
						<div class="instagram-logo">
							<a href="'.esc_url($author_url).'" target="_blank">
								<i class="fa fa-instagram"></i>
								<span class="name">@'.$author_name.'</span>
							</a>
						</div>
						<a href="'.esc_attr($media_url).'" target="_blank">
						<div class="instagram-stats">
							<i class="fa fa-heart"></i>
						</div>
						</a>
					</div>
				</div>';
	    }
		return $out;
	}
	add_shortcode('solieninstapost', 'SolienInstagramPost');
}
add_filter( 'widget_text', 'shortcode_unautop', 7);
add_filter( 'widget_text', 'do_shortcode', 7);
add_filter( 'the_content', 'do_shortcode', 120);

// Remove Empty Paragraphs
add_filter("the_content", "solien_the_content_filter");
function solien_the_content_filter($content) {
	// array of custom shortcodes requiring the fix 
	$block = join("|", array('post_slider'));
	$array = array(
		'<p>[' => '[', 
		']</p>' => ']', 
		']<br />' => ']',
		']<br>' => ']',	
		'<br>[' => '[',
		'<p></p>' => '',
		'<p><script' => '<script',
		'<p><style' => '<style',
		'</style></p>' => '</style>',
		'</script><br />' => '</script>',
		'</script></p>' => '</script>'
	);
	$content = strtr($content, $array);
	// opening tag
	$rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]", $content); 
	// closing tag
	$rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]", $rep);
	return $rep;
}
?>