<?php

add_action( 'init', 'solien_elements_vc_shortcodes' );
function solien_elements_vc_shortcodes() {
	$imageSizes = get_intermediate_image_sizes();
	$imageSizes[]= 'full';
	vc_map( 
		array(
			"name" => __("Solien Posts Slider", 'solien-elements'),
			"base" => "post_slider",
			"icon" => 'asw-element-icon dashicons dashicons-slides',
			"category" => __('Solien Elements', 'solien-elements'),
			'front_enqueue_js' => array(SOLIEN_PLUGIN_URL.'js/owl-carousel.min.js'),
			'description' => __('Slider with your posts', 'solien-elements'),
			"params" => array(
				array(
					"type" => "dropdown",            
					"heading" => __("Autoplay", 'solien-elements'),
					"param_name" => "slideshow",
					"value" => array(
					   __('Enable', 'solien-elements')=>'true',
					   __('Disable', 'solien-elements')=>'false',
					),
					"description" => __("Disable or Enable Autoplay.", 'solien-elements'),
					"std" => array('true')
				),		
				array(
					"type" => "textfield",            
					"heading" => __("Slider count", 'solien-elements'),
					"param_name" => "number_posts",
					"value" => '3',
					'admin_label' => true,
					"description" => __("Enter number of slides to display (Note: Enter '-1' to display all slides).", 'solien-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Category slug", 'solien-elements'),
					"param_name" => "cat_slug",
					"value" => '',
					"description" => __("This help you to retrieve items from specific category. More than one separate by commas.", 'solien-elements')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Post IDs", 'solien-elements'),
					"param_name" => "post_ids",
					"value" => '',
					"description" => __("Enter posts IDs to display only those records (Note: separate values by commas (,)).", 'solien-elements')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Order by", 'solien-elements'),
					"param_name" => "orderby",
					"value" => array(
					   __('Date', 'solien-elements')=>'date', 
					   __('Last modified date', 'solien-elements') => 'modified',
					   __('Popularity', 'solien-elements')=>'comment_count',
					   __('Title', 'solien-elements')=>'title',
					   __('Random', 'solien-elements')=>'rand',
					   __('Preserve post ID order', 'solien-elements') => 'post__in',
					),
					"description" => __('Select how to sort retrieved posts.', 'solien-elements'),
					"std" => array('date')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Sort order", 'solien-elements'),
					"param_name" => "order",
					"value" => array(
					   __('Descending', 'solien-elements')=>'DESC', 
					   __('Ascending', 'solien-elements')=>'ASC'
					),
					"description" => __('Select ascending or descending order.', 'solien-elements'),
					"std" => array('DESC')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Image size", 'solien-elements'),
					"param_name" => "thumbsize",
					"value" => $imageSizes,
					"description" => __('Select your image size to use in slider.', 'solien-elements'),
					"std" => array('large')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Slider Style", 'solien-elements'),
					"param_name" => "style",
					"value" => array(
					   __('Centered', 'solien-elements')=>'center',
					   __('Simple', 'solien-elements')=>'simple',
					   __('Three in row', 'solien-elements') => 'three_per_row',
					),
					"std" => array('simple')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Slider width", 'solien-elements'),
					"param_name" => "slider_width",
					"value" => array(
					   __('Fullwidth', 'solien-elements') => 'fullwidth',
					   __('Standard', 'solien-elements') => 'standard',
					),
					"std" => array('standard')
				),
			)
		)
	);
	vc_map( 
		array(
			"name" => __("Solien List Posts", 'solien-elements'),
			"base" => "listposts",
			"icon" => 'asw-element-icon dashicons dashicons-admin-post',
			"category" => __('Solien Elements', 'solien-elements'),
			'description' => __('Show WP posts. Latest, Popular or from specific category, etc.', 'solien-elements'),
			"params" => array(		
				array(
					"type" => "textfield",            
					"heading" => __("Post count", 'solien-elements'),
					"param_name" => "num",
					"value" => '3',
					'admin_label' => true,
					"description" => __("Enter number of posts to display (Note: Enter '-1' to display all posts).", 'solien-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Category slug", 'solien-elements'),
					"param_name" => "cat_slug",
					"value" => '',
					"description" => __("This help you to retrieve items from specific category. More than one separate by commas.", 'solien-elements')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Post IDs", 'solien-elements'),
					"param_name" => "post_ids",
					"value" => '',
					"description" => __("Enter posts IDs to display only those records (Note: separate values by commas (,)).", 'solien-elements')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Sort order", 'solien-elements'),
					"param_name" => "order",
					"value" => array(
					   __('Descending', 'solien-elements')=>'DESC', 
					   __('Ascending', 'solien-elements')=>'ASC'
					),
					"description" => __('Select ascending or descending order.', 'solien-elements'),
					"std" => array('DESC')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Thumbnail size", 'solien-elements'),
					"param_name" => "thumbsize",
					"value" => $imageSizes,
					"description" => __('Select your image size to use.', 'solien-elements'),
					"std" => array('medium')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Post excerpt count", 'solien-elements'),
					"param_name" => "excerpt_count",
					"value" => '32',
					"description" => __("Enter number of words in post excerpt.", 'solien-elements')            
				),
				array(
		            "type" => "dropdown",            
		            "heading" => __("Pagination", 'solien-elements'),
		            "param_name" => "pagination",
		            "value" => array(__('Enable','solien-elements')=>'true', __('Disable', 'solien-elements')=>'false'),
		            "description" => __('Enable or Disable pagination for posts.', 'solien-elements'),
		            "std" => array('false')
		        ),
		        array(
		            "type" => "dropdown",            
		            "heading" => __("Ignore sticky posts", 'solien-elements'),
		            "param_name" => "ignore_sticky_posts",
		            "value" => array(__('True','solien-elements')=>'true', __('False', 'solien-elements')=>'false'),
		            "description" => __('Show sticky posts?', 'solien-elements'),
		            "std" => array('false')
		        ),
			)
		)
	);
	vc_map( 
		array(
			"name" => __("Solien Grid Posts", 'solien-elements'),
			"base" => "gridposts",
			"icon" => 'asw-element-icon dashicons dashicons-layout',
			"category" => __('Solien Elements', 'solien-elements'),
			'description' => __('Show WP posts in grid.', 'solien-elements'),
			"params" => array(
				array(
					"type" => "textfield",            
					"heading" => __("Posts block title", 'solien-elements'),
					"param_name" => "block_title",
					"value" => '',
					'admin_label' => true,
					"description" => __("Enter posts block title e.g. 'Latest posts'. Leave blank if you need not to display it.", 'solien-elements')            
				),		
				array(
					"type" => "textfield",            
					"heading" => __("Post count", 'solien-elements'),
					"param_name" => "number_posts",
					"value" => '3',
					'admin_label' => true,
					"description" => __("Enter number of posts to display (Note: Enter '-1' to display all posts).", 'solien-elements')            
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Columns count", 'solien-elements'),
					"param_name" => "columns",
					'admin_label' => false,
					"value" => array(
					   __('Two per row', 'solien-elements')=>'span6',
					   __('Three per row', 'solien-elements')=>'span4',
					   __('Four per row', 'solien-elements')=>'span3',
					   __('Five per row', 'solien-elements')=>'one_fifth',
					   __('Six per row', 'solien-elements')=>'span2',
					),
					"description" => __("Select posts count per row.", 'solien-elements'),
					"std" => array('span4')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Category slug", 'solien-elements'),
					"param_name" => "cat_slug",
					"value" => '',
					'admin_label' => true,
					"description" => __("This help you to retrieve items from specific category. More than one separate by commas.", 'solien-elements')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Post IDs", 'solien-elements'),
					"param_name" => "post_ids",
					"value" => '',
					"description" => __("Enter posts IDs to display only those records (Note: separate values by commas (,)).", 'solien-elements')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Order by", 'solien-elements'),
					"param_name" => "orderby",
					"value" => array(
					   __('Date', 'solien-elements')=>'date', 
					   __('Last modified date', 'solien-elements') => 'modified',
					   __('Popularity', 'solien-elements')=>'comment_count',
					   __('Title', 'solien-elements')=>'title',
					   __('Random', 'solien-elements')=>'rand',
					   __('Preserve post ID order', 'solien-elements') => 'post__in',
					),
					"description" => __('Select how to sort retrieved posts.', 'solien-elements'),
					"std" => array('date')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Sort order", 'solien-elements'),
					"param_name" => "order",
					"value" => array(
					   __('Descending', 'solien-elements')=>'DESC', 
					   __('Ascending', 'solien-elements')=>'ASC'
					),
					"description" => __('Select ascending or descending order.', 'solien-elements'),
					"std" => array('DESC')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Thumbnail size", 'solien-elements'),
					"param_name" => "thumbSize",
					"value" => $imageSizes,
					"description" => __('Select your image size to use.', 'solien-elements'),
					"std" => array('medium')
				),
			)
		)
	);
	vc_map( 
		array(
			"name" => __("Solien Carousel Posts", 'solien-elements'),
			"base" => "carouselposts",
			"icon" => 'asw-element-icon dashicons dashicons-leftright',
			'front_enqueue_js' => array(SOLIEN_PLUGIN_URL.'js/owl-carousel.min.js'),
			"category" => __('Solien Elements', 'solien-elements'),
			'description' => __('Show WP posts in grid.', 'solien-elements'),
			"params" => array(
				array(
					"type" => "textfield",            
					"heading" => __("Posts block title", 'solien-elements'),
					"param_name" => "block_title",
					"value" => '',
					'admin_label' => true,
					"description" => __("Enter posts block title e.g. 'Latest posts'. Leave blank if you need not to display it.", 'solien-elements')            
				),		
				array(
					"type" => "textfield",            
					"heading" => __("Post count", 'solien-elements'),
					"param_name" => 'posts_count',
					"value" => '3',
					"description" => __("Enter number of posts to display (Note: Enter '-1' to display all posts).", 'solien-elements')            
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Posts per view", 'solien-elements'),
					"param_name" => "columns",
					"value" => array(
					   __('Two per view', 'solien-elements')=>'span6',
					   __('Three per view', 'solien-elements')=>'span4',
					   __('Four per view', 'solien-elements')=>'span3',
					   __('Five per view', 'solien-elements')=>'one_fifth',
					   __('Six per view', 'solien-elements')=>'span2',
					),
					"description" => __("Select posts count per view.", 'solien-elements'),
					"std" => array('one_fifth')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Category slug", 'solien-elements'),
					"param_name" => "cat_slug",
					"value" => '',
					"description" => __("This help you to retrieve items from specific category. More than one separate by commas.", 'solien-elements')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Post IDs", 'solien-elements'),
					"param_name" => "post_ids",
					"value" => '',
					"description" => __("Enter posts IDs to display only those records (Note: separate values by commas (,)).", 'solien-elements')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Order by", 'solien-elements'),
					"param_name" => "orderby",
					"value" => array(
					   __('Date', 'solien-elements')=>'date', 
					   __('Last modified date', 'solien-elements') => 'modified',
					   __('Popularity', 'solien-elements')=>'comment_count',
					   __('Title', 'solien-elements')=>'title',
					   __('Random', 'solien-elements')=>'rand',
					   __('Preserve post ID order', 'solien-elements') => 'post__in',
					),
					"description" => __('Select how to sort retrieved posts.', 'solien-elements'),
					"std" => array('date')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Sort order", 'solien-elements'),
					"param_name" => "order",
					"value" => array(
					   __('Descending', 'solien-elements')=>'DESC', 
					   __('Ascending', 'solien-elements')=>'ASC'
					),
					"description" => __('Select ascending or descending order.', 'solien-elements'),
					"std" => array('DESC')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Thumbnail size", 'solien-elements'),
					"param_name" => "thumbsize",
					"value" => $imageSizes,
					"description" => __('Select your image size to use.', 'solien-elements'),
					"std" => array('medium')
				),
			)
		)
	);
	vc_map( 
		array(
			"name" => __("Solien Recent Posts", 'solien-elements'),
			"base" => "recentposts",
			"icon" => 'asw-element-icon dashicons dashicons-format-aside',
			"category" => __('Solien Elements', 'solien-elements'),
			'description' => __('Show WP posts. Latest, Popular or from specific category, etc.', 'solien-elements'),
			"params" => array(		
				array(
					"type" => "textfield",            
					"heading" => __("Post count", 'solien-elements'),
					"param_name" => "num",
					"value" => '3',
					'admin_label' => true,
					"description" => __("Enter number of posts to display (Note: Enter '-1' to display all posts).", 'solien-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Category slug", 'solien-elements'),
					"param_name" => "cat_slug",
					"value" => '',
					"description" => __("This help you to retrieve items from specific category. More than one separate by commas.", 'solien-elements')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Post IDs", 'solien-elements'),
					"param_name" => "post_ids",
					"value" => '',
					"description" => __("Enter posts IDs to display only those records (Note: separate values by commas (,)).", 'solien-elements')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Order by", 'solien-elements'),
					"param_name" => "orderby",
					"value" => array(
					   __('Date', 'solien-elements')=>'date', 
					   __('Last modified date', 'solien-elements') => 'modified',
					   __('Popularity', 'solien-elements')=>'comment_count',
					   __('Title', 'solien-elements')=>'title',
					   __('Random', 'solien-elements')=>'rand',
					   __('Preserve post ID order', 'solien-elements') => 'post__in',
					),
					"description" => __('Select how to sort retrieved posts.', 'solien-elements'),
					"std" => array('date')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Sort order", 'solien-elements'),
					"param_name" => "order",
					"value" => array(
					   __('Descending', 'solien-elements')=>'DESC', 
					   __('Ascending', 'solien-elements')=>'ASC'
					),
					"description" => __('Select ascending or descending order.', 'solien-elements'),
					"std" => array('DESC')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Thumbnail size", 'solien-elements'),
					"param_name" => "thumbsize",
					"value" => $imageSizes,
					"description" => __('Select your image size to use.', 'solien-elements'),
					"std" => array('medium')
				),
				array(
		            "type" => "dropdown",            
		            "heading" => __("Pagination", 'solien-elements'),
		            "param_name" => "pagination",
		            "value" => array(__('Enable','solien-elements')=>'true', __('Disable', 'solien-elements')=>'false'),
		            "description" => __('Enable or Disable pagination for posts.', 'solien-elements'),
		            "std" => array('false')
		        ),
		        array(
		            "type" => "dropdown",            
		            "heading" => __("Ignore sticky posts", 'solien-elements'),
		            "param_name" => "ignore_sticky_posts",
		            "value" => array(__('True','solien-elements')=>'true', __('False', 'solien-elements')=>'false'),
		            "description" => __('Show sticky posts?', 'solien-elements'),
		            "std" => array('false')
		        ),
			)
		)
	);
	vc_map( 
		array(
			"name" => __("Solien Socials", 'solien-elements'),
			"base" => "soliensocials",
			"icon" => 'asw-element-icon dashicons dashicons-networking',
			"category" => __('Solien Elements', 'solien-elements'),
			'description' => __('Show social icons: facebook, twitter, pinterest, etc.', 'solien-elements'),
			"params" => array(		
				array(
					"type" => "textfield",            
					"heading" => __("Facebook", 'solien-elements'),
					"param_name" => "facebook",
					'admin_label' => true,
					"value" => '',
					"description" => __("Enter link to your account (profile).", 'solien-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Twitter", 'solien-elements'),
					"param_name" => "twitter",
					'admin_label' => true,
					"value" => '',
					"description" => __("Enter link to your account (profile).", 'solien-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Pinterest", 'solien-elements'),
					"param_name" => "pinterest",
					'admin_label' => true,
					"value" => '',
					"description" => __("Enter link to your account (profile).", 'solien-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Instagram", 'solien-elements'),
					"param_name" => "instagram",
					'admin_label' => true,
					"value" => '',
					"description" => __("Enter link to your account (profile).", 'solien-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Tumblr", 'solien-elements'),
					"param_name" => "tumblr",
					'admin_label' => true,
					"value" => '',
					"description" => __("Enter link to your account (profile).", 'solien-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Rss", 'solien-elements'),
					"param_name" => "rss",
					'admin_label' => true,
					"value" => '',
					"description" => __("Enter link to rss.", 'solien-elements')            
				),	
			)
		)
	);
	vc_map( 
		array(
			"name" => __("Solien User Info", 'solien-elements'),
			"base" => "solienuser",
			"icon" => 'asw-element-icon dashicons dashicons-admin-users',
			"category" => __('Solien Elements', 'solien-elements'),
			'description' => __('Show user information.', 'solien-elements'),
			"params" => array(		
				array(
					"type" => "textfield",            
					"heading" => __("Username", 'solien-elements'),
					"param_name" => "username",
					"value" => '',
					'admin_label' => true,
					"description" => __("Enter username parameter to display information.", 'solien-elements')            
				),
			)
		)
	);
	vc_map( 
		array(
			"name" => __("Solien Call To Action", 'solien-elements'),
			"base" => "soliencta",
			"icon" => 'asw-element-icon dashicons dashicons-megaphone',
			"category" => __('Solien Elements', 'solien-elements'),
			'description' => __('Show special block with button.', 'solien-elements'),
			"params" => array(		
				array(
					"type" => "textfield",            
					"heading" => __("Button label", 'solien-elements'),
					"param_name" => "button_label",
					"value" => '',
					'admin_label' => true,
					"description" => __("Enter button label.", 'solien-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Button Url", 'solien-elements'),
					"param_name" => "button_url",
					"value" => '',
					"description" => __("Enter button url.", 'solien-elements')            
				),
				array(
					"type" => "attach_image",            
					"heading" => __("Background image", 'solien-elements'),
					"param_name" => "bg_image_id",
					"value" => '',
					"description" => __("Select image for block background.", 'solien-elements')          
				),
			)
		)
	);
}
?>