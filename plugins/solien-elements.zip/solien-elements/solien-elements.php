<?php
/**
 * Plugin Name: Solien Elements
 * Description: This plugin is required for use with Solien theme. It gathers all shortcodes and elements from Solien theme. It gives a possibility to keep this content data even if you switch the theme to another one. This is a part of new Envato requirements for WordPress theme developers.
 * Version: 1.2.4
 * Author: MontakCo
 * Author URI: http://themeforest.net/user/montaukco/portfolio
 * Text Domain: solien-elements
 * Domain Path: /languages
*/

add_action( 'plugins_loaded', 'solien_plugin_load_textdomain' );
/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 */
function solien_plugin_load_textdomain() {
  load_plugin_textdomain( 'solien-elements', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}

$dir = plugin_dir_path( __FILE__ );
define( 'SOLIEN_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );

include_once ( trailingslashit( $dir ).'update.php' );
include_once ( trailingslashit( $dir ).'inc/shortcodes.php' );
//iclude widgets
include_once(trailingslashit( $dir ).'inc/widgets/twitter.php' );
include_once(trailingslashit( $dir ).'inc/widgets/socials.php'); // add socials widget
include_once(trailingslashit( $dir ).'inc/widgets/aboutme.php'); // add aboutMe widget
include_once(trailingslashit( $dir ).'inc/widgets/latestposts.php'); // add latest posts widget
include_once(trailingslashit( $dir ).'inc/widgets/instagram.php'); // add instagram widget
/* Include Meta Box Script */
include_once(trailingslashit( $dir ).'inc/meta-boxes.php');

if(class_exists('WPBakeryVisualComposerAbstract')) {
	include_once( trailingslashit( $dir ).'inc/vc-shortcodes.php');
}

function solien_shortcodes_scripts() {  
	wp_register_script('owl-carousel', SOLIEN_PLUGIN_URL . 'js/owl.carousel.min.js', array('jquery'), '2.3.4', TRUE);
	wp_register_script('isotope', SOLIEN_PLUGIN_URL . 'js/isotope.min.js', array('jquery'), '3.0.0', true);
}
add_action( 'wp_enqueue_scripts', 'solien_shortcodes_scripts' );
function solien_shortcodes_styles() {  
	wp_register_style( 'owl-carousel', SOLIEN_PLUGIN_URL . 'css/owl.carousel.css', array(), '2.3.4', 'all' );
}
add_action( 'wp_enqueue_scripts', 'solien_shortcodes_styles', 5);

if(!function_exists('SolienSharebox')){
	function SolienSharebox($postID, $echo = false){
		if(is_front_page()){
			$permalink = esc_url(home_url());
			$title = esc_attr(get_bloginfo('name'));
			$description = esc_attr(get_bloginfo('description'));
		} else {
			$permalink = esc_url(get_permalink($postID));
			$title = esc_attr(get_the_title($postID));
			$description = esc_attr(get_the_title($postID));
		}

		$out = '<div class="sharebox">';
			$out .= '<div class="social-icons">';
				$out .= '<ul class="unstyled">';
					if( get_theme_mod('asw_sharing_facebook',true) ) $out .= '<li class="social-facebook"><a href="//www.facebook.com/sharer.php?u='.esc_url($permalink).'&amp;t='.str_replace(' ', '+', $title).'" title="'.esc_html__( 'Share to Facebook', 'solien-elements').'" target="_blank"><i class="fa fa-facebook"></i></a></li>';
					if( get_theme_mod('asw_sharing_twitter',true) ) $out .= '<li class="social-twitter"><a href="//twitter.com/home?status='.str_replace(' ', '+', $title).'+'.esc_url($permalink).'" title="'.esc_html__( 'Share to Twitter', 'solien-elements').'" target="_blank"><i class="fa fa-twitter"></i></a></li>';	
					if( get_theme_mod('asw_sharing_pinterest',true) ) $out .= '<li class="social-pinterest"><a href="//pinterest.com/pin/create/link/?url='.esc_url($permalink).'&amp;media='.wp_get_attachment_url( get_post_thumbnail_id($postID) ).'&amp;description='.str_replace(" ", "+", $description).'" title="'.esc_html__( 'Share to Pinterest', 'solien-elements').'" target="_blank"><i class="fa fa-pinterest-p"></i></a></li>';
					if( get_theme_mod('asw_sharing_linkedin',false) ) $out .= '<li class="social-linkedin"><a href="http://linkedin.com/shareArticle?mini=true&amp;url='.esc_url($permalink).'&amp;title='.str_replace(' ', '+', $title).'" title="'.esc_html__( 'Share to LinkedIn', 'solien').'" target="_blank"><i class="fa fa-linkedin"></i></a></li>';
					if( get_theme_mod('asw_sharing_googleplus',false) ) $out .= '<li class="social-googleplus"><a href="http://plus.google.com/share?url='.esc_url($permalink).'&amp;title='.str_replace(' ', '+', $title).'" title="'.esc_html__( 'Share To Google+', 'solien').'" target="_blank"><i class="fa fa-google-plus"></i></a></li>';
					if( get_theme_mod('asw_sharing_email',false) ) $out .= '<li class="social-email"><a href="mailto:?subject='.str_replace(' ', '+', $title).'&amp;body='.esc_url($permalink).'" title="'.esc_html__( 'Share with E-Mail', 'solien').'" target="_blank"><i class="fa fa-envelope"></i></a></li>';
				$out .= '</ul>';
			$out .= '</div>';
		$out .= '</div>';
		if($echo){
			echo $out;
		} else {
			return $out;
		}
	}
}
if(!function_exists('solien_get_the_content')){
	function solien_get_the_content() {
		$content = get_the_content();
		$content = apply_filters('the_content', $content);
		$content = str_replace(']]>', ']]&gt;', $content);
		return $content;
	}
}
if(!function_exists('solien_post_has_more_link')){
	function solien_post_has_more_link( $post_id ) {
		$post = get_post( $post_id );
		$content = $post->post_content;
		$data_array = get_extended( $content );
		return '' !== $data_array['extended'];
	}
}
if(!function_exists('solien_custom_pagination')){
  function solien_custom_pagination($pages = '') {

    $out ='';

    global $paged;
	if(empty($paged)) $paged = 1;

    if($pages == '') {
      global $wp_query;
      $pages = $wp_query->max_num_pages;
      if(!$pages) {
        $pages = 1;
      }
    }
    
    if(1 != $pages) {
      if($paged > 1) {
      	$out .= get_previous_posts_link(esc_html__('Newer posts', 'solien'));
      } else {
      	$out .= '<span class="previous nonactive">'.esc_html__('Newer posts', 'solien').'</span>';
      }
      if ($paged < $pages) {
      	$out .= get_next_posts_link(esc_html__('Older posts', 'solien'));
      } else {
      	$out .= '<span class="next nonactive">'.esc_html__('Older posts', 'solien').'</span>';
      }
    }
    return $out;
  }
}
if(!function_exists('solien_string_limit_words')){
	function solien_string_limit_words($string, $word_limit)
	{
	  $string = strip_tags($string, '<p>');
	  $words = explode(' ', $string, ($word_limit + 1));
	  if(count($words) > $word_limit)
	    array_pop($words);
	  return implode(' ', $words);
	}
}
if(!function_exists('SolienCommentsNumber')){
	function SolienCommentsNumber($postID, $echo = false){
		$num_comments = get_comments_number($postID);
		if ( comments_open() ) {
			if ( $num_comments == 0 ) {
				$comments = esc_html__('No Comments', 'solien-elements');
			} elseif ( $num_comments > 1 ) {
				$comments = $num_comments .' '. esc_html__('Comments', 'solien-elements');
			} else {
				$comments = esc_html__('1 Comment', 'solien-elements');
			}
			$write_comments = '<a href="' . get_comments_link($postID) .'"><i class="la la-comment"></i> '. $comments.'</a>';
		} else {
			$write_comments =  '<span><i class="la la-comment"></i> '.esc_html__('Comments disabled.', 'solien-elements').'</span>';
		}
		if($echo){
			echo $write_comments;
		} else {
			return $write_comments;
		}
	}
	add_filter( 'SolienCommentsNumber', 'SolienCommentsNumber' );
}
add_action('admin_head', 'solien_custom_fonts');
function solien_custom_fonts() {
  $solien_icon_style = '.asw-element-icon {
      width:32px;
      height:32px;
      line-height:32px !important;
      border-radius:4px;
      background-image:none !important;
      background-color:#2b2735;
      color:#ffffff;
      font-size:22px !important;
      text-align:center;
    }';
  wp_add_inline_style('js_composer', $solien_icon_style);
}
if(!function_exists('SolienExcerpt')){
	function SolienExcerpt($limit) {
		$excerpt = explode(' ', get_the_excerpt(), $limit);
		if (count($excerpt)>=$limit) {
			array_pop($excerpt);
			$excerpt = implode(" ",$excerpt);
		} else {
			$excerpt = implode(" ",$excerpt);
		} 
		$excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
		return $excerpt;
	}
}
if(!function_exists('solien_additional_user_fields')){
	function solien_additional_user_fields( $user ) {?>
	    <h3><?php _e( 'Additional User Meta', 'solien' ); ?></h3>
	    <table class="form-table">
	        <tr>
	            <th><label for="user_meta_image"><?php esc_html_e( 'A special image for each user', 'solien' ); ?></label></th>
	            <td>
	                <!-- Outputs the image after save -->
	                <img id="additional-user-image" src="<?php echo esc_url( get_the_author_meta( 'user_meta_image', $user->ID ) ); ?>" style="width:150px;"><br />
	                <!-- Outputs the text field and displays the URL of the image retrieved by the media uploader -->
	                <input type="text" name="user_meta_image" id="user_meta_image" value="<?php echo esc_url_raw( get_the_author_meta( 'user_meta_image', $user->ID ) ); ?>" class="regular-text" />
	                <!-- Outputs the save button -->
	                <input type='button' class="additional-user-image button-primary" value="<?php _e( 'Upload Image', 'solien' ); ?>" id="uploadimage"/><br />
	                <span class="description"><?php esc_html_e( 'Upload an additional image for your user profile.', 'solien' ); ?></span>
	            </td>
	        </tr>
	        <tr>
	            <th><h4><?php esc_html_e( 'User socials icons', 'solien' ); ?></h4></th>
	            <td>
	                <p>
	                    <label for="user_facebook_url"><?php esc_html_e( 'Facebook:', 'solien' ); ?></label><br>
	                    <input type="text" name="user_facebook_url" id="user_facebook_url" value="<?php echo esc_url_raw( get_the_author_meta( 'user_facebook_url', $user->ID ) ); ?>" class="regular-text" />
	                </p>
	                <p>
	                    <label for="user_twitter_url"><?php esc_html_e( 'Twitter:', 'solien' ); ?></label><br>
	                    <input type="text" name="user_twitter_url" id="user_twitter_url" value="<?php echo esc_url_raw( get_the_author_meta( 'user_twitter_url', $user->ID ) ); ?>" class="regular-text" />
	                </p>
	                <p>
	                    <label for="user_pinterest_url"><?php esc_html_e( 'Pinterest:', 'solien' ); ?></label><br>
	                    <input type="text" name="user_pinterest_url" id="user_pinterest_url" value="<?php echo esc_url_raw( get_the_author_meta( 'user_pinterest_url', $user->ID ) ); ?>" class="regular-text" />
	                </p>
	                <p>
	                    <label for="user_instagram_url"><?php esc_html_e( 'Instagram:', 'solien' ); ?></label><br>
	                    <input type="text" name="user_instagram_url" id="user_instagram_url" value="<?php echo esc_url_raw( get_the_author_meta( 'user_instagram_url', $user->ID ) ); ?>" class="regular-text" />
	                </p>
	                <p>
	                    <label for="user_tumblr_url"><?php esc_html_e( 'Tumblr:', 'solien' ); ?></label><br>
	                    <input type="text" name="user_tumblr_url" id="user_tumblr_url" value="<?php echo esc_url_raw( get_the_author_meta( 'user_tumblr_url', $user->ID ) ); ?>" class="regular-text" />
	                </p>
	                <p>
	                    <label for="user_rss_show"><input type="checkbox" name="user_rss_show" id="user_rss_show" value="false" <?php checked( get_the_author_meta( 'user_rss_show', $user->ID ), 'false' ); ?> /><?php esc_html_e('Disable rss icon','solien'); ?></label>
	            </p><br>
	                <span class="description"><?php esc_html_e( 'Enter your socials links to user profile. Leave blank to hide icon.', 'solien' ); ?></span>
	            </td>
	        </tr>
	 
	    </table><!-- end form-table -->
	<?php } // additional_user_fields
	add_action( 'show_user_profile', 'solien_additional_user_fields' );
	add_action( 'edit_user_profile', 'solien_additional_user_fields' );
}
if(!function_exists('solien_save_additional_user_meta')){
	function solien_save_additional_user_meta( $user_id ) {
	 
	    // only saves if the current user can edit user profiles
	    if ( !current_user_can( 'edit_user', $user_id ) )
	        return false;
	 
	    update_user_meta( $user_id, 'user_meta_image', $_POST['user_meta_image'] );
	    update_user_meta( $user_id, 'user_facebook_url', $_POST['user_facebook_url'] );
	    update_user_meta( $user_id, 'user_twitter_url', $_POST['user_twitter_url'] );
	    update_user_meta( $user_id, 'user_pinterest_url', $_POST['user_pinterest_url'] );
	    update_user_meta( $user_id, 'user_instagram_url', $_POST['user_instagram_url'] );
	    update_user_meta( $user_id, 'user_tumblr_url', $_POST['user_tumblr_url'] );
	    update_user_meta( $user_id, 'user_rss_show', $_POST['user_rss_show'] );
	}
	 
	add_action( 'personal_options_update', 'solien_save_additional_user_meta' );
	add_action( 'edit_user_profile_update', 'solien_save_additional_user_meta' );
}

if(!function_exists('solien_user_photo_scripts') ){
	function solien_user_photo_scripts() {
		global $pagenow;
		if($pagenow !== 'profile.php') return;
		wp_enqueue_media(); 
		wp_enqueue_script('solien-author-photo', SOLIEN_PLUGIN_URL . 'js/author.photo.js', array('jquery'), '1.0.0');
	}
	add_action('admin_enqueue_scripts', 'solien_user_photo_scripts');
}
if(!function_exists('solien_get_attachment_image_by_url')){
	function solien_get_attachment_image_by_url( $url ) {
 
    // Split the $url into two parts with the wp-content directory as the separator.
    $parse_url  = explode( parse_url( WP_CONTENT_URL, PHP_URL_PATH ), $url );
 
    // Get the host of the current site and the host of the $url, ignoring www.
    $this_host = str_ireplace( 'www.', '', parse_url( home_url(), PHP_URL_HOST ) );
    $file_host = str_ireplace( 'www.', '', parse_url( $url, PHP_URL_HOST ) );
 
    // Return nothing if there aren't any $url parts or if the current host and $url host do not match.
    if ( !isset( $parse_url[1] ) || empty( $parse_url[1] ) || ( $this_host != $file_host ) ) {
        return;
    }
 
    // Now we're going to quickly search the DB for any attachment GUID with a partial path match.
    // Example: /uploads/2013/05/test-image.jpg
    global $wpdb;
 
    $prefix     = $wpdb->prefix;
    $attachment = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM " . $prefix . "posts WHERE guid RLIKE %s;", $parse_url[1] ) );
 
    // Returns null if no attachment is found.
    return $attachment[0];
}
}

if(!function_exists('solien_get_additional_user_meta_thumb')){
	function solien_get_additional_user_meta_thumb($user_id='') {
	 	global $post;
	 	if($user_id == ''){
	 		$user_id = $post->post_author;
	 	}
	    $attachment_url = esc_url( get_the_author_meta( 'user_meta_image', $user_id ) );
	 
	     // grabs the id from the URL using Frankie Jarretts function
	    $attachment_id = solien_get_attachment_image_by_url( $attachment_url );
	 
	    // retrieve the thumbnail size of our image
	    $image_thumb = wp_get_attachment_image_src( $attachment_id, 'thumbnail' );
	 
	    // return the image thumbnail
	    return $image_thumb[0];
	 
	}
}

if( !function_exists('solien_get_user_socials') ){
	function solien_get_user_socials($user_id='') {
	 	global $post;
	 	if($user_id == ''){
	 		$user_id = $post->post_author;
	 	}
	    $facebook = get_the_author_meta( 'user_facebook_url', $user_id );
	    $twitter = get_the_author_meta( 'user_twitter_url', $user_id );
	    $pinterest = get_the_author_meta( 'user_pinterest_url', $user_id );
	    $instagram = get_the_author_meta( 'user_instagram_url', $user_id );
	    $tumblr = get_the_author_meta( 'user_tumblr_url', $user_id );
	    $rss_feed = get_author_feed_link($user_id, '');
	    $user_rss_show = get_the_author_meta( 'user_rss_show', $user_id );
	    if($facebook != "" || $twitter != "" || $pinterest != "" || $instagram != '' || $tumblr != "") $output = '<div class="social-icons"><ul class="unstyled">';
		if($facebook != "") { 
			$output .= '<li class="social-facebook"><a href="'.esc_url($facebook).'" target="_blank" title="'.esc_html__( 'Facebook', 'solien').'"><i class="fa fa-facebook"></i></a></li>';
		}
		if($twitter != "") { 
			$output .= '<li class="social-twitter"><a href="'.esc_url($twitter).'" target="_blank" title="'.esc_html__( 'Twitter', 'solien').'"><i class="fa fa-twitter"></i></a></li>';
		}
		if($pinterest != "") { 
			$output .= '<li class="social-pinterest"><a href="'.esc_url($pinterest).'" target="_blank" title="'.esc_html__( 'Pinterest', 'solien').'"><i class="fa fa-pinterest-p"></i></a></li>';
		}
		if($instagram != '') { 
			$output .= '<li class="social-instagram"><a href="'.esc_url($instagram).'" target="_blank" title="'.esc_html__( 'Instagram', 'solien').'"><i class="fa fa-instagram"></i></a></li>';
		}
		if($tumblr != "") { 
			$output .= '<li class="social-tumblr"><a href="'.esc_url($tumblr).'" target="_blank" title="'.esc_html__( 'Tumblr', 'solien').'"><i class="fa fa-tumblr"></i></a></li>';
		}
		if($user_rss_show != 'false') { 
			$output .= '<li class="social-rss"><a href="'.esc_url($rss_feed).'" target="_blank" title="'.esc_html__( 'RSS', 'solien').'"><i class="fa fa-rss"></i></a></li>';
		} 
	    if($facebook != "" || $twitter != "" || $pinterest != "" || $instagram != '' || $tumblr != "") $output .= '</ul></div>';
	    
		return $output;
	}
}
// Echo theme's meta data if enabled
if(!function_exists('asw_header_meta')) {
	/**
	 * Function that echoes meta data if our seo is enabled
	 */
	function asw_header_meta() {
		if( get_theme_mod('asw_responsiveness', true) ) {
			echo '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">';
		}
		$metas = '';
		if( !get_theme_mod('asw_seo_settings', false) ) {
			$meta_description = esc_html(get_post_meta(get_the_ID(), "asw_page_meta_description", true));
			$meta_keywords = esc_html(get_post_meta(get_the_ID(), "asw_page_meta_keywords", true));
			if($meta_description) { 
				$metas .= '<meta name="description" content="'.$meta_description.'">'."\r\n";
			} else if( get_theme_mod('asw_meta_description', false) ){
				$metas .= '<meta name="description" content="'.get_theme_mod('asw_meta_description').'">'."\r\n";
			}
			if($meta_keywords) {
				$metas .= '<meta name="keywords" content="'.$meta_keywords.'">'."\r\n";
			} else if( get_theme_mod('asw_meta_keywords', false) ){
				$metas .= '<meta name="keywords" content="'.get_theme_mod('asw_meta_keywords').'">'."\r\n";
			}
		}
		echo ''.$metas;
	}
	add_action('asw_header_meta', 'asw_header_meta');
}
if(!function_exists('solien_get_social_links')){
	function solien_get_social_links(){
		$output='';
		$output .= '<div class="social-icons">';
			$output .= '<ul class="unstyled">';
			
			if(get_theme_mod('asw_social_twitter', '') != "") { 
				$output .= '<li class="social-twitter"><a href="'.esc_url(get_theme_mod('asw_social_twitter', '')).'" target="_blank" title="'. esc_html__( 'Twitter', 'solien').'"><i class="fa fa-twitter"></i></a></li>';
			}
			if(get_theme_mod('asw_social_pinterest', '') != "") { 
				$output .= '<li class="social-pinterest"><a href="'.esc_url(get_theme_mod('asw_social_pinterest', '')).'" target="_blank" title="'. esc_html__( 'Pinterest', 'solien').'"><i class="fa fa-pinterest-p"></i></a></li>';
			}
			if(get_theme_mod('asw_social_facebook', '') != "") { 
				$output .= '<li class="social-facebook"><a href="'.esc_url(get_theme_mod('asw_social_facebook', '')).'" target="_blank" title="'. esc_html__( 'Facebook', 'solien').'"><i class="fa fa-facebook"></i></a></li>';
			}
			if(get_theme_mod('asw_social_vimeo', '') != "") { 
				$output .= '<li class="social-vimeo"><a href="'.esc_url(get_theme_mod('asw_social_vimeo', '')).'" target="_blank" title="'. esc_html__( 'Vimeo', 'solien').'"><i class="fa fa-vimeo"></i></a></li>';
			}	 
			if(get_theme_mod('asw_social_instagram', '') != '') { 
				$output .= '<li class="social-instagram"><a href="'.esc_url(get_theme_mod('asw_social_instagram', '')).'" target="_blank" title="'. esc_html__( 'Instagram', 'solien').'"><i class="fa fa-instagram"></i></a></li>';
			}
			if(get_theme_mod('asw_social_tumblr', '') != "") { 
				$output .= '<li class="social-tumblr"><a href="'.esc_url(get_theme_mod('asw_social_tumblr', '')).'" target="_blank" title="'. esc_html__( 'Tumblr', 'solien').'"><i class="fa fa-tumblr"></i></a></li>';
			}
			if(get_theme_mod('asw_social_google_plus', '') != "") { 
				$output .= '<li class="social-googleplus"><a href="'.esc_url(get_theme_mod('asw_social_google_plus', '')).'" target="_blank" title="'. esc_html__( 'Google plus', 'solien').'"><i class="fa fa-google-plus"></i></a></li>';
			}
			if(get_theme_mod('asw_social_forrst', '') != "") { 
				$output .= '<li class="social-forrst"><a href="'.esc_url(get_theme_mod('asw_social_forrst', '')).'" target="_blank" title="'. esc_html__( 'Forrst', 'solien').'"><i class="fa icon-forrst"></i></a></li>';
			}
			if(get_theme_mod('asw_social_dribbble', '') != "") { 
				$output .= '<li class="social-dribbble"><a href="'.esc_url(get_theme_mod('asw_social_dribbble', '')).'" target="_blank" title="'. esc_html__( 'Dribbble', 'solien').'"><i class="fa fa-dribbble"></i></a></li>';
			}
			if(get_theme_mod('asw_social_flickr', '') != "") { 
				$output .= '<li class="social-flickr"><a href="'.esc_url(get_theme_mod('asw_social_flickr', '')).'" target="_blank" title="'. esc_html__( 'Flickr', 'solien').'"><i class="fa fa-flickr"></i></a></li>';
			}
			if(get_theme_mod('asw_social_linkedin', '') != "") { 
				$output .= '<li class="social-linkedin"><a href="'.esc_url(get_theme_mod('asw_social_linkedin', '')).'" target="_blank" title="'. esc_html__( 'LinkedIn', 'solien').'"><i class="fa fa-linkedin"></i></a></li>';
			}
			if(get_theme_mod('asw_social_skype', '') != "") { 
				$output .= '<li class="social-skype"><a href="skype:'.esc_attr(get_theme_mod('asw_social_skype', '')).'" title="'. esc_html__( 'Skype', 'solien').'"><i class="fa fa-skype"></i></a></li>';
			}
			if(get_theme_mod('asw_social_digg', '') != "") { 
				$output .= '<li class="social-digg"><a href="'.esc_url(get_theme_mod('asw_social_digg', '')).'" target="_blank" title="'. esc_html__( 'Digg', 'solien').'"><i class="fa fa-digg"></i></a></li>';
			}
			if(get_theme_mod('asw_social_yahoo', '') != "") { 
				$output .= '<li class="social-yahoo"><a href="'.esc_url(get_theme_mod('asw_social_yahoo', '')).'" target="_blank" title="'. esc_html__( 'Yahoo', 'solien').'"><i class="fa fa-yahoo"></i></a></li>';
			}
			if(get_theme_mod('asw_social_youtube', '') != "") { 
				$output .= '<li class="social-youtube"><a href="'.esc_url(get_theme_mod('asw_social_youtube', '')).'" target="_blank" title="'. esc_html__( 'YouTube', 'solien').'"><i class="fa fa-youtube"></i></a></li>';
			}
			if(get_theme_mod('asw_social_deviantart', '') != "") { 
				$output .= '<li class="social-deviantart"><a href="'.esc_url(get_theme_mod('asw_social_deviantart', '')).'" target="_blank" title="'. esc_html__( 'DeviantArt', 'solien').'"><i class="fa fa-deviantart"></i></a></li>';
			}
			if(get_theme_mod('asw_social_behance', '') != "") { 
				$output .= '<li class="social-behance"><a href="'.esc_url(get_theme_mod('asw_social_behance', '')).'" target="_blank" title="'. esc_html__( 'Behance', 'solien').'"><i class="fa fa-behance"></i></a></li>';
			}
			if(get_theme_mod('asw_social_paypal', '') != "") { 
				$output .= '<li class="social-paypal"><a href="'.esc_url(get_theme_mod('asw_social_paypal', '')).'" target="_blank" title="'. esc_html__( 'PayPal', 'solien').'"><i class="fa fa-paypal"></i></a></li>';
			}
			if(get_theme_mod('asw_social_delicious', '') != "") { 
				$output .= '<li class="social-delicious"><a href="'.esc_url(get_theme_mod('asw_social_delicious', '')).'" target="_blank" title="'. esc_html__( 'Delicious', 'solien').'"><i class="fa fa-delicious"></i></a></li>';
			}
			if(get_theme_mod('asw_social_rss', false)) { 
				$output .= '<li class="social-rss"><a href="'.esc_url(get_bloginfo('rss2_url')).'" target="_blank" title="'. esc_html__( 'RSS', 'solien').'"><i class="fa fa-rss"></i></a></li>';
			} 
			$output .= '</ul>';
		$output .= '</div>';
		echo ''.$output;
	}
}
?>