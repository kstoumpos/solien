<?php get_header(); ?>

<?php 
// Get Blog Layout from Theme Options
if(get_theme_mod('asw_sidebar_pos', 'sidebar-right') != 'none'){
	$sidebar_pos = get_theme_mod('asw_sidebar_pos', 'sidebar-right').' span9';
} else {
	$sidebar_pos ='span12';
}
?>
<div id="page-wrap-blog" class="container">
	<div id="content" class="<?php echo esc_attr($sidebar_pos); ?>">
		<div class="row-fluid">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<div itemscope itemtype="http://schema.org/Article" <?php post_class('post-masonry span6 standard'); ?> role="article">
						<div class="post-content-container aligncenter">
							<?php if( has_post_thumbnail() ) {?>
								<figure class="post-img" itemprop="image"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_post_thumbnail('masonry'); ?></a></figure>
							<?php } ?>
							<div class="meta-categories"><?php echo get_the_category_list(', '); ?></div>
							<header class="title">
								<h3 itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__('Permalink to %s', 'solien'), the_title_attribute('echo=0') ); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
							</header>
							<div class="meta-date<?php if (get_theme_mod( 'asw_posts_headings_separator', true ) ) echo ' separator'; ?>"><span><?php echo esc_html__('Posted by', 'solien').' '.get_the_author(); ?></span><time datetime="<?php echo date(DATE_W3C); ?>"><?php echo esc_html__('On', 'solien').' '; the_time(get_option('date_format')); ?></time></div>
							<?php if (!has_post_thumbnail() && solien_post_has_more_link( get_the_ID() ) ) {
								echo '<div class="post-excerpt">'.solien_get_the_content().'</div>';
							} ?>
						</div>
					</div>
				<?php 
			endwhile;
			
			echo '<div class="clearfix"></div>';
			
			get_template_part( 'framework/inc/nav' ); 
			?>
				
			<?php else : ?>
				
				<h2><?php esc_html_e('Not Found', 'solien') ?></h2>
				
			<?php endif; ?>
		</div>
	</div>

<?php if(get_theme_mod('asw_sidebar_pos', 'sidebar-right') != 'none'){
		get_sidebar();
	} 
?>
</div>

<?php get_footer(); ?>
