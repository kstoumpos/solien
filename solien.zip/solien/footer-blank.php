		</div> <!-- end boxed -->
	
	<?php wp_footer(); ?>
	</body>
</html>
