		<?php if( is_active_sidebar('before-footer-widgets') ) { ?>
			<div id="before-footer">
				<?php if ( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar('Before footer area') ); ?>
			</div>
		<?php } ?>
		<?php if( is_active_sidebar('footer-widgets') ) { ?>
			<footer id="footer">
				<div class="container">
					<div class="span12 aligncenter">
						<?php if ( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar('Footer') ); ?>	
					</div>	
				</div>
			</footer>
		<?php } ?>	
			<?php if( get_theme_mod('asw_footer_copyright', '') != '' ) { ?>
			<div id="footer-copy-block" class="aligncenter">
				<div class="container">
					<div class="span12">
						<div class="copyright-text"><?php echo get_theme_mod('asw_footer_copyright', ''); ?></div>
					</div>
				</div>
			</div><!-- end footer-nav-block -->
			<?php } ?>
			<div class="clear"></div>
		</div> <!-- end boxed -->
	
	<?php wp_footer(); ?>
	</body>
</html>
