<?php
function solien_compress( $minify ) 
{
/* remove comments */
    $minify = preg_replace( '!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $minify );

    /* remove tabs, spaces, newlines, etc. */
    $minify = str_replace( array("\r\n", "\r", "\n", "\t", '; ', '  ', '    ', '    ',': ', ', ','{ ','}.'), array('','','','',';','','','',':',',','{','} .'), $minify );
        
    return $minify;
}
/**
 * Add color styling from theme
 */
function solien_styles_custom() {
?>
<?php ob_start(); ?>
body {
    font-family: <?php echo get_theme_mod( 'asw_body_font_family', 'Arimo' ); ?>;
    font-size: <?php echo get_theme_mod( 'asw_body_font_size', '15px' ); ?>;
    color: <?php echo get_theme_mod('asw_body_color', '#333333'); ?>;
}
a {
   color: <?php echo get_theme_mod('asw_links_color', '#be816c'); ?>; 
}
a:hover {
   color: <?php echo get_theme_mod('asw_links_color_hover', '#a7a8aa'); ?>; 
}
#header {
	<?php 
    echo "background-color: ".get_theme_mod('asw_header_bg_color', '#1a2423').";";
    echo "background-image: url(".get_theme_mod('asw_header_image', '').");";
    echo "background-size: ".get_theme_mod('asw_header_bg_size', 'auto').";";
    echo "background-position: 50% 50%;";
    echo "border-color: ".get_theme_mod('asw_header_border_color', '#1a2423').";";
    ?>
}
#navigation li ul {
    background-color: <?php echo get_theme_mod('asw_header_bg_color', '#1a2423'); ?>;
}
.logo img {
    width: <?php echo get_theme_mod( 'asw_media_logo_width', '185' ); ?>px;
}
#navigation .menu li a { 
    font-size: <?php echo get_theme_mod( 'asw_menu_font_size', '11px' ); ?>;
    font-weight: <?php echo get_theme_mod( 'asw_menu_font_weight', '600' ); ?>;
    font-family: <?php echo get_theme_mod( 'asw_menu_font_family', 'Montserrat' ); ?>;
    color: <?php echo get_theme_mod('asw_menu_item_color', '#fff'); ?>;
}
#navigation .menu li ul li a {
    font-family: <?php echo get_theme_mod( 'asw_menu_font_family', 'Montserrat' ); ?>;
    font-weight: <?php echo get_theme_mod( 'asw_menu_font_weight', '600' ); ?>;
    color: <?php echo get_theme_mod('asw_menu_item_color', '#fff'); ?>;
}
.menu-button-open, .search-link .search-button, .cart-main .my-cart-link {
    color: <?php echo get_theme_mod('asw_menu_item_color', '#fff'); ?>;
}
ul#nav-mobile li > a:hover, ul#nav-mobile li.current-menu-item > a, ul#nav-mobile li.current_page_item > a, ul#nav-mobile li.current-menu-ancestor > a,
#navigation .menu li > a:hover, #navigation .menu li.current-menu-item > a, #navigation .menu li.current-menu-ancestor > a,
.menu-button-open:hover, .search-link .search-button:hover, .cart-main .my-cart-link:hover,
#navigation .menu li ul li a:hover,
#navigation .menu li ul .current-menu-item > a,
#navigation .menu li ul .current-menu-ancestor > a {
    color: <?php echo get_theme_mod('asw_menu_item_color_active', '#aaadad'); ?>;
}
#footer, 
#footer-nav-block,
#footer-copy-block { background-color: <?php echo get_theme_mod('asw_footer_bg_color', '#171c1b'); ?>; }
#footer-nav-block,
#footer-copy-block {border-color: <?php echo get_theme_mod('asw_footer_br_color', '#171c1b'); ?>;}
#footer-nav.menu li a { 
    font-size: <?php echo get_theme_mod( 'asw_footer_menu_font_size', '10px' ); ?>;
    font-family: <?php echo get_theme_mod( 'asw_footer_menu_font_family', 'Montserrat' ); ?>;
    color: <?php echo get_theme_mod('asw_footer_menu_item_color', '#fff'); ?>;
    border-color: <?php echo get_theme_mod('asw_footer_header_border_color', '#e5e5e5'); ?>;
}
#footer-copy-block {
    font-size: <?php echo get_theme_mod( 'asw_footer_copyright_font_size', '11px' ); ?>;
    font-family: <?php echo get_theme_mod( 'asw_footer_copyright_font_family', 'Montserrat' ); ?>;
    color: <?php echo get_theme_mod('asw_footer_copyright_color', '#aaadad'); ?>;
}
#footer-nav.menu li > a:hover, #footer-nav.menu li.current-menu-item > a, #footer-nav.menu li.current-menu-ancestor > a {
    color: <?php echo get_theme_mod('asw_footer_menu_item_color_active', '#aaadad'); ?>;
}
.title h2, .title h3 { 
    font-family: <?php echo get_theme_mod( 'asw_posts_headings_font_family', 'Montserrat' ); ?>;
    color: <?php echo get_theme_mod('asw_posts_headings_item_color', '#2b2735'); ?>;
    font-weight: <?php echo get_theme_mod( 'asw_posts_headings_font_weight', '500' ); ?>;
    font-size: <?php echo get_theme_mod( 'asw_posts_headings_font_size', '26' ); ?>px;
}
blockquote {
    font-family: <?php echo get_theme_mod( 'asw_posts_headings_font_family', 'Montserrat' ); ?>;
}
h1,h2,h3,h4 {
    font-family: <?php echo get_theme_mod( 'asw_posts_headings_font_family', 'Montserrat' ); ?>;
    color: <?php echo get_theme_mod('asw_posts_headings_item_color', '#2b2735'); ?>;
    font-weight: <?php echo get_theme_mod( 'asw_posts_headings_font_weight', '500' ); ?>;
}
 h3.related-item-title { 
    font-family: <?php echo get_theme_mod( 'asw_posts_headings_font_family', 'Montserrat' ); ?>;
    color: <?php echo get_theme_mod('asw_posts_headings_item_color', '#2b2735'); ?>;
}
.woocommerce div.product p.price, .woocommerce div.product span.price {
    color:<?php echo get_theme_mod('asw_accent_color', '#be816c'); ?> !important;
    font-family: <?php echo get_theme_mod( 'asw_posts_headings_font_family', 'Montserrat' ); ?> !important;
}
.title h2 a:hover, .title h3 a:hover, .related-item-title a:hover, .latest-blog-item-description a.title:hover {
    color: <?php echo get_theme_mod('asw_posts_headings_item_color_active', '#be816c'); ?>;
}
.wpb_widgetised_column .widget h3.title, .widget-title,
#related-posts h2, #comments #reply-title, #comments-title,
.write-comment h3 {
    font-size: <?php echo get_theme_mod( 'asw_widgets_headings_font_size', '10px' ); ?>; 
    font-weight: <?php echo get_theme_mod( 'asw_widgets_headings_font_weight', '600' ); ?>;
    font-family: <?php echo get_theme_mod( 'asw_widgets_headings_font_family', 'Montserrat' ); ?>;
    color: <?php echo get_theme_mod('asw_widgets_headings_item_color', '#2b2735'); ?>;
}
blockquote:before,
.widget .latest-blog-list .meta-categories a:hover, .post-meta .meta-tags a:hover,
.post .meta-categories, .author .comment-reply a:hover, .pie-top-button, #header .social-icons li a:hover,
.post .social-icons li a:hover, #mobile-nav .social-icons li a:hover,
.post-meta .sharebox a, .post-meta .meta-comment a:hover {
    color:<?php echo get_theme_mod('asw_accent_color', '#be816c'); ?>;
}
.woocommerce ul.products li.product .price {
    color:<?php echo get_theme_mod('asw_accent_color', '#be816c'); ?> !important;
}
.instagram-item:hover img,
input[type="text"]:focus,
input[type="password"]:focus,
input[type="email"]:focus,
input[type="url"]:focus,
input[type="tel"]:focus,
input[type="number"]:focus,
textarea:focus,
.single-post .post.featured .title .meta-date .meta-categories a {
    border-color:<?php echo get_theme_mod('asw_accent_color', '#be816c'); ?>;
}
#sidebar .widget.widget_socials .social-icons li a:before,
input[type="submit"]:hover, .button:hover, button:hover,
input[type="submit"]:hover, .pie,
#footer .social-icons li a:before, .sk-folding-cube .sk-cube:before,
.woocommerce span.onsale,
.owl-post-slider .owl-nav div:hover {
    background-color:<?php echo get_theme_mod('asw_accent_color', '#be816c'); ?> !important;
}
<?php $out=ob_get_contents(); $out = solien_compress($out); ob_end_clean();

    wp_add_inline_style('solien-stylesheet', $out);
}
add_action( 'wp_enqueue_scripts', 'solien_styles_custom' );
?>