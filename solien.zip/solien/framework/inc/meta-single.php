<?php 
if ( comments_open() ) : ?>
	<span class="meta meta-comment">
		<?php solien_comments_number(get_the_ID(), true); ?>
	</span>
<?php endif; ?>
<?php if(comments_open()) { ?> 
<div class="write-comment"><h3><a href="#reply-title"><?php esc_html_e('Write a comment', 'solien'); ?></h3></a></div> 
<?php } else { ?>
<div class="write-comment"><h3><?php esc_html_e('Comments disabled', 'solien'); ?></h3></div>
<?php } ?>
<?php
if(function_exists('SolienSharebox')){
	SolienSharebox(get_the_ID(), true);
}
?>