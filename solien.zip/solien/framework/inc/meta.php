<span class="meta meta-comment">
	<?php solien_comments_number(get_the_ID(), true); ?>
</span>
<div class="post-more"><a href="<?php the_permalink(); ?>" class="post-more-link" title="<?php printf( esc_attr__('Permalink to %s', 'solien'), the_title_attribute('echo=0') ); ?>" rel="bookmark"><i class="la la-angle-right icon1"></i><i class="la la-long-arrow-right icon2"></i></a></div>
<?php
if(function_exists('SolienSharebox')){
	SolienSharebox(get_the_ID(), true);
}
?>

	