<?php if(solien_custom_pagination() != '') { ?>
<div id="pagination" class="clearfix">
	<?php echo solien_custom_pagination(); ?>
</div>
<?php } ?>