<?php
/* ------------------------------------------------------------------------ */
/* Define Sidebars */
/* ------------------------------------------------------------------------ */
if(!function_exists('solien_widgets_init')){
	add_action( 'widgets_init', 'solien_widgets_init' );
	function solien_widgets_init(){
		if (function_exists('register_sidebar')) {
			if (get_theme_mod( 'asw_posts_headings_separator', true ) ) 
				$separator = ' separator';
			else {
				$separator = '';
			}
			/* ------------------------------------------------------------------------ */
			/* Blog Widgets */
			register_sidebar(array(
				'name' => esc_html__('Blog Widgets','solien'),
				'id'   => 'blog-widgets',
				'description'   => esc_html__( 'These are widgets for the Blog sidebar.','solien' ),
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<h3 class="widget-title'.$separator.'"><span>',
				'after_title'   => '</span></h3>'
			));
			/* ------------------------------------------------------------------------ */
			/* Hidden Area Widgets */
			register_sidebar(array(
				'name' => esc_html__('Hidden Menu Widgets','solien'),
				'id'   => 'hidden-widgets',
				'description'   => esc_html__( 'These are widgets for hidden menu block.','solien' ),
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<h3 class="widget-title"><span>',
				'after_title'   => '</span></h3>'
			));

			/* Hidden Area Widgets */
			register_sidebar(array(
				'name' => esc_html__('Before footer area','solien'),
				'id'   => 'before-footer-widgets',
				'description'   => esc_html__( 'These are widgets for before footer area.','solien' ),
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<h3 class="widget-title">',
				'after_title'   => '</h3>'
			));

			/*Footer*/
			register_sidebar(array(
				'name' => esc_html__('Footer','solien'),
				'id'   => 'footer-widgets',
				'description'   => esc_html__( 'These are widgets for footer area.','solien' ),
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<h3 class="widget-title">',
				'after_title'   => '</h3>'
			));
		}
	}
}
    
?>