<?php 
/* ------------------------------------------------------------------------ */
/* Translation
/* Translations can be filed in the framework/languages/ directory */

load_theme_textdomain( 'solien', get_template_directory() . '/languages' );

$locale = get_locale();
$locale_file = get_template_directory() . "/languages/$locale.php";
if ( is_readable($locale_file) ){
	require_once($locale_file);
}

include_once(trailingslashit( get_template_directory() ).'framework/customizer/customizer.php'); // Enqueue JavaScripts & CSS
include_once(trailingslashit( get_template_directory() ).'framework/inc/customcss.php');

include_once(trailingslashit( get_template_directory() ).'framework/inc/sidebars.php'); // register widgets area
include_once(trailingslashit( get_template_directory() ).'framework/inc/sidebar-generator.php'); // add custom sidebars

if(!function_exists('solien_scripts_basic')){
	function solien_scripts_basic() {  
		wp_scripts()->add_data( 'jquery', 'group', 1 );
		wp_scripts()->add_data( 'jquery-core', 'group', 1 );
		wp_scripts()->add_data( 'jquery-migrate', 'group', 1 );
		if ( is_singular() ) { 
			wp_enqueue_script( 'comment-reply' ); 
		} 
		wp_enqueue_script('html5', get_template_directory_uri().'/js/html5shiv.js', array(), '3.7.3' );
		wp_script_add_data('html5', 'conditional', 'lt IE 9' );
		wp_enqueue_script('owl-carousel', get_template_directory_uri() . '/js/owl.carousel.min.js', array('jquery'), '2.0.0', TRUE);
		wp_enqueue_script('image-lightbox', get_template_directory_uri() . '/js/image-lightbox.min.js', array('jquery'), '1.0', TRUE);
		wp_enqueue_script('isotope', get_template_directory_uri() . '/js/isotope.min.js', array('jquery'), '3.0.0', true);
		wp_enqueue_script('infinite-scroll', get_template_directory_uri() . '/js/infinite-scroll.pkgd.min.js', array('jquery'), '2.1.0', true);
		wp_enqueue_script('imagesloaded', get_template_directory_uri() . '/js/imagesloaded.pkgd.min.js', array('jquery'), '4.1.4', true);
		wp_enqueue_script('jquery-scrolltofixed', get_template_directory_uri() . '/js/jquery.scrolltofixed.min.js', array('jquery'), '1.0', true);
		wp_enqueue_script('theia-sticky-sidebar', get_template_directory_uri() . '/js/theia-sticky-sidebar.js', array('jquery'), '1.7.0', true);
		wp_enqueue_script('solien-functions', get_template_directory_uri() . '/js/solien-functions.js', array('jquery'), '1.0', TRUE);
	}
	add_action( 'wp_enqueue_scripts', 'solien_scripts_basic', 11 );
}

if(!function_exists('solien_styles_basic')){
	function solien_styles_basic() {  
		/* ------------------------------------------------------------------------ */
		/* Register Stylesheets */
		/* ------------------------------------------------------------------------ */
		wp_register_style( 'solien-basic', get_template_directory_uri() . '/css/basic.css', array(), '1.0', 'all' );
		wp_register_style( 'solien-stylesheet', get_template_directory_uri() .'/style.css', array(), '1.0', 'all' );
		wp_register_style( 'solien-skeleton', get_template_directory_uri() . '/css/grid.css', array(), '1', 'all' );
		wp_register_style( 'image-lightbox', get_template_directory_uri() . '/css/imageLightbox.min.css', array(), '1.0', 'all' );
		wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/framework/fonts/font-awesome/css/font-awesome.min.css', array(), '4.7.0', 'all' );
		wp_enqueue_style( 'line-awesome', get_template_directory_uri() . '/framework/fonts/line-awesome/css/line-awesome.min.css', array(), '1.0', 'all' );
		wp_enqueue_style( 'owl-carousel', get_template_directory_uri() . '/css/owl.carousel.css', array(), '2.0.0', 'all' );
		wp_register_style( 'solien-responsive', get_template_directory_uri() . '/css/responsive.css', array(), '1.0', 'all' );

		wp_enqueue_style( 'solien-basic' );
		wp_enqueue_style( 'solien-skeleton' );
		wp_enqueue_style( 'image-lightbox' );
		wp_enqueue_style( 'solien-stylesheet' );
		if( get_theme_mod('asw_responsiveness', true) ) {
			wp_enqueue_style( 'solien-responsive' );
		}

	}  
	add_action( 'wp_enqueue_scripts', 'solien_styles_basic', 1 );
}

if(!function_exists('solien_enqueue_comments_reply')){
	function solien_enqueue_comments_reply(){
		wp_enqueue_script( 'comment-reply' );
	}
	add_action( 'comment_form_before', 'solien_enqueue_comments_reply' );
}

/* Add Custom Primary Navigation */
if(!function_exists('solien_register_custom_menu')){
	add_action('init', 'solien_register_custom_menu');
	function solien_register_custom_menu() {
		register_nav_menu('main_navigation', esc_html__('Main Navigation','solien'));
	}
}

if(!function_exists('solien_comments_number')){
	function solien_comments_number($postID, $echo = false){
		$num_comments = get_comments_number($postID);
		if ( comments_open() ) {
			if ( $num_comments == 0 ) {
				$comments = esc_html__('No Comments', 'solien');
			} elseif ( $num_comments > 1 ) {
				$comments = $num_comments .' '. esc_html__('Comments', 'solien');
			} else {
				$comments = esc_html__('1 Comment', 'solien');
			}
			$write_comments = '<a href="' . get_comments_link($postID) .'"><i class="la la-comment"></i> '. $comments.'</a>';
		} else {
			$write_comments = '<span><i class="la la-comment"></i> '.esc_html__('Comments disabled.', 'solien').'</span>';
		}
		if($echo){
			echo ''.$write_comments;
		} else {
			return $write_comments;
		}
	}
	add_filter( 'solien_comments_number', 'solien_comments_number' );
}

if(!function_exists('solien_string_limit_words')){
	function solien_string_limit_words($string, $word_limit)
	{
	  $string = strip_tags($string, '<p>');
	  $words = explode(' ', $string, ($word_limit + 1));
	  if(count($words) > $word_limit)
	    array_pop($words);
	  return implode(' ', $words);
	}
}

if(!function_exists('solien_theme_setup')){
	function solien_theme_setup() {
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support('post-formats', array('gallery', 'image', 'video', 'audio', 'quote'));
		set_post_thumbnail_size( '830', '550', true );
		add_image_size(esc_html__('solien-masonry', 'solien'), 470, 9999, false);
		add_image_size(esc_html__('solien-extra-medium', 'solien'), 470, 410, true);
		add_image_size(esc_html__('solien-slider', 'solien'), 1170, 648, true);
		add_image_size(esc_html__('solien-fullwidth-slider', 'solien'), 1900, 650, true);

		update_option( 'thumbnail_size_w', 160 );
		update_option( 'thumbnail_size_h', 160 );
		update_option( 'thumbnail_crop', 1 );

		update_option( 'medium_size_w', 570 );
		update_option( 'medium_size_h', 380 );
		update_option( 'medium_crop', 1 );

		update_option( 'large_size_w', 1170 );
		update_option( 'large_size_h', 730 );
		update_option( 'large_crop', 1 );
	}
	add_action( 'after_setup_theme', 'solien_theme_setup' );	
}

if(!function_exists('solien_custom_excerpt_length')){
	function solien_custom_excerpt_length( $length ) {
		return 75;
	}
	add_filter( 'excerpt_length', 'solien_custom_excerpt_length', 999 );
}

if(!function_exists('solien_woocommerce_my_single_title')){
	add_action('woocommerce_single_product_summary', 'solien_woocommerce_my_single_title',5);
	function solien_woocommerce_my_single_title() {
		echo '<header class="title"><h2 itemprop="headline">'.get_the_title().'</h2></header>';
	}
}

if(!function_exists('solien_modify_read_more_link')){
	add_filter('excerpt_more', 'solien_modify_read_more_link');
	add_filter( 'the_content_more_link', 'solien_modify_read_more_link' );
	function solien_modify_read_more_link() {
		return '';
	}
}

/* Pagination */
if(!function_exists('solien_next_posts_link_attributes')){
	add_filter('next_posts_link_attributes', 'solien_next_posts_link_attributes');
	function solien_next_posts_link_attributes() {
	    return 'class="next"';
	}
}
if(!function_exists('solien_prev_posts_link_attributes')){
	function solien_prev_posts_link_attributes() {
    	return 'class="previous"';
	}
	add_filter('previous_posts_link_attributes', 'solien_prev_posts_link_attributes');
}


if(!function_exists('solien_post_has_more_link')){
	function solien_post_has_more_link( $post_id ) {
		$post = get_post( $post_id );
		$content = $post->post_content;
		$data_array = get_extended( $content );
		return '' !== $data_array['extended'];
	}
}
if(!function_exists('solien_custom_pagination')){
  function solien_custom_pagination($pages = '', $range = 4) {
    $showitems = ($range * 2)+1;
    $out ='';
    global $paged;
    if(empty($paged)) $paged = 1;
    
    if($pages == '') {
      global $wp_query;
      $pages = $wp_query->max_num_pages;
      if(!$pages) {
        $pages = 1;
      }
    }
    
    if(1 != $pages) {
      if($paged > 1) {
      	$out .= get_previous_posts_link(esc_html__('Newer posts', 'solien'));
      } else {
      	$out .= '<span class="previous nonactive">'.esc_html__('Newer posts', 'solien').'</span>';
      }
      if ($paged < $pages) {
      	$out .= get_next_posts_link(esc_html__('Older posts', 'solien'));
      } else {
      	$out .= '<span class="next nonactive">'.esc_html__('Older posts', 'solien').'</span>';
      }
    }
    return $out;
  }
}

/* ------------------------------------------------------------------------ */
/* Comments
/* ------------------------------------------------------------------------ */
if(!function_exists('solien_move_comment_field_to_bottom')){
	function solien_move_comment_field_to_bottom( $fields ) {
		$comment_field = $fields['comment'];
		unset( $fields['comment'] );
		$fields['comment'] = $comment_field;
		return $fields;
	}
	add_filter( 'comment_form_fields', 'solien_move_comment_field_to_bottom' );
}
	
if(!function_exists('solien_comment')){
	function solien_comment( $comment, $args, $depth ) {
	   $GLOBALS['comment'] = $comment; ?>
	   <li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
	   <div id="comment-<?php comment_ID(); ?>" class="comment-body clearfix"> 
	   		
	   			<?php
				if ( function_exists( 'solien_get_additional_user_meta_thumb' ) && get_comment()->user_id ){
					// retrieve our additional author meta info
					$user_meta_image = esc_attr( get_the_author_meta( 'user_meta_image', get_comment()->user_id ) );
				    // make sure the field is set
				    if ( isset( $user_meta_image ) && $user_meta_image ) {
				        // only display if function exists
				        ?>
							<div class="author-avatar"><img alt="<?php esc_html_e('author photo', 'solien'); ?>" src="<?php echo solien_get_additional_user_meta_thumb(); ?>" /></div>
				        <?php } ?>
				<?php } else {
					if( get_avatar( $comment, '70', '' ) ) { echo '<div class="author-avatar">'.get_avatar( $comment, '70', '' ).'</div>'; }
				} ?>

	        <div class="comment-text">
				<div class="author">
				 	<h2 class="author-title"><?php printf( esc_html__( '%s', 'solien'), get_comment_author_link() ) ?></h2>
				 	<div class="date-comment"><?php printf(esc_html__('%1$s', 'solien'), get_comment_date('F j. Y')) ?><?php edit_comment_link( esc_html__( '(Edit)', 'solien'),' ','' ) ?></div>  
					<div class="comment-reply"><?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?></div>
				</div>
				<div class="text clearfix">
				<?php comment_text() ?>
				<?php if ( $comment->comment_approved == '0' ) : ?>
			        <em><?php esc_html_e( 'Your comment is awaiting moderation.', 'solien') ?></em>
			        <br />
		      	<?php endif; ?>
		      </div>
	      	</div>
	   </div>
	<?php
	}
}
if(!function_exists('rwmb_meta')){
	function rwmb_meta($key) {
		return get_post_meta(get_the_ID(), $key);
	}
}
// Define Content Width 
if(! isset( $content_width)){
	$content_width = 830;
	function solien_adjust_content_width() {
		if( is_page_template( 'page-nosidebar.php' )){
			$content_width = 1200;
		}
	}   
	add_action( 'template_redirect', 'solien_adjust_content_width' );
}
add_theme_support( "title-tag" );
if(!function_exists('solien_wp_title')) {
	function solien_wp_title($title, $sep) {
		$id = get_the_ID();
		$title_prefix = esc_attr(get_bloginfo('name'));
		$title_suffix = '';
		$unchanged_title = $title;
		$title = is_front_page() ? $title_prefix.' - '.esc_attr(get_bloginfo('description')) : $title.$title_prefix.' - '.esc_attr(get_bloginfo('description'));
		return $title;
	}
	add_filter('wp_title', 'solien_wp_title', 10, 2);
}

/* ------------------------------------------------------------------------ */
/* Automatic Plugin Activation */
require_once(trailingslashit( get_template_directory() ). 'framework/inc/class-tgm-plugin-activation.php');
/* ------------------------------------------------------------------------ */
// Recommended plugins activation
if(!function_exists('solien_register_required_plugins')){
	add_action('tgmpa_register', 'solien_register_required_plugins');
	function solien_register_required_plugins() {
		$plugins = array(

			array(
	        	'name'      => esc_html__('Contact Form 7', 'solien'),
	        	'slug'      => 'contact-form-7',
				'required' 	=> false, 
	        ),
			array(
	        	'name'      => esc_html__('Meta Box', 'solien'),
	        	'slug'      => 'meta-box',
				'required' 	=> false, 
	        ),
	        array(
	        	'name'      => esc_html__('MailChimp', 'solien'),
	        	'slug'      => 'mailchimp-for-wp',
				'required' 	=> false, 
	        ),
	        array(
	        	'name'      => esc_html__('WooCommerce', 'solien'),
	        	'slug'      => 'woocommerce',
				'required' 	=> false, 
	        ),
	        array(
	        	'name'      => esc_html__('One Click Demo Import','solien'),
	        	'slug'      => 'one-click-demo-import',
				'required' 	=> false,
	        ),
	        array(
	        	'name'      		=> esc_html__('Visual Composer','solien'),
	        	'slug'      		=> 'js_composer',
	        	'source'   			=> esc_url(get_template_directory_uri() . '/framework/plugins/js_composer.zip'),
				'required' 			=> false,
	        ),
	        array(
	        	'name'      		=> esc_html__('Solien elements','solien'),
	        	'slug'      		=> 'solien-elements',
	        	'source'   			=> esc_url(get_template_directory_uri() . '/framework/plugins/solien-elements.zip'),
				'required' 			=> true,
	        )
		);

		/**
		 * Array of configuration settings. Amend each line as needed.
		 * If you want the default strings to be available under your own theme domain,
		 * leave the strings uncommented.
		 * Some of the strings are added into a sprintf, so see the comments at the
		 * end of each line for what each argument will be.
		 */
		$config = array(
			'domain'       		=> 'solien',         	// Text domain - likely want to be the same as your theme.
			'default_path' 		=> '',                         	// Default absolute path to pre-packaged plugins
			'menu'         		=> 'install-required-plugins', 	// Menu slug
			'has_notices'      	=> true,                       	// Show admin notices or not
			'is_automatic'    	=> true,					   	// Automatically activate plugins after installation or not
			'message' 			=> '',							// Message to output right before the plugins table
			'strings'      		=> array(
				'page_title'                       			=> esc_html__( 'Install Required Plugins', 'solien' ),
				'menu_title'                       			=> esc_html__( 'Install Plugins', 'solien' ),
				'installing'                       			=> esc_html__( 'Installing Plugin: %s', 'solien' ), // %1$s = plugin name
				'oops'                             			=> esc_html__( 'Something went wrong with the plugin API.', 'solien' ),
				'return'                           			=> esc_html__( 'Return to Required Plugins Installer', 'solien' ),
				'plugin_activated'                 			=> esc_html__( 'Plugin activated successfully.', 'solien' ),
				'complete' 									=> esc_html__( 'All plugins installed and activated successfully. %s', 'solien' ), // %1$s = dashboard link
				'nag_type'									=> 'updated' // Determines admin notice type - can only be 'updated' or 'error'
			)
		);
		tgmpa($plugins, $config);
	}	
}

if(!function_exists('solien_import_files')){
	function solien_import_files() {
	    return array(
	        array(
	            'import_file_name'           => esc_html__('Full Demo import','solien'),
	            'local_import_file'            => trailingslashit( get_template_directory() ).'framework/import/demo.xml',
	            'local_import_widget_file'     => trailingslashit( get_template_directory() ).'framework/import/widgets.wie',
	            'local_import_customizer_file' => trailingslashit( get_template_directory() ).'framework/import/customizer.dat',
	            'import_preview_image_url'   => trailingslashit( get_template_directory_uri() ).'framework/import/preview_blog.png',
	            'preview_url'                => 'http://www.solien.tunethemes.net/',
	        ),
	        array(
	            'import_file_name'           => esc_html__('Import settings','solien'),
	            'local_import_customizer_file' => trailingslashit( get_template_directory() ).'framework/import/customizer.dat',
	            'import_preview_image_url'   => trailingslashit( get_template_directory_uri() ).'framework/import/preview_settings.png',
	            'preview_url'                => 'http://www.solien.tunethemes.net/',
	        ),
	        array(
	            'import_file_name'           => esc_html__('Import widgets','solien'),
	            'local_import_widget_file'     => trailingslashit( get_template_directory() ).'framework/import/widgets.wie',
	            'import_preview_image_url'   => trailingslashit( get_template_directory_uri() ).'framework/import/preview_widgets.png',
	            'preview_url'                => 'http://www.solien.tunethemes.net/',
	        )
	    );
	}
	add_filter( 'pt-ocdi/import_files', 'solien_import_files' );
}
if(!function_exists('solien_after_import_setup')){
	function solien_after_import_setup() {
	    // Assign menus to their locations.
	    $main_menu = get_term_by( 'name', 'Main menu', 'nav_menu' );

	    set_theme_mod( 'nav_menu_locations', array(
	            'main_navigation' => $main_menu->term_id,
	        )
	    );
	}
	add_action( 'pt-ocdi/after_import', 'solien_after_import_setup' );
	add_filter( 'pt-ocdi/disable_pt_branding', '__return_true' );
}

if(!class_exists('Solien_Mobile_Walker_Nav_Menu')){
	class Solien_Mobile_Walker_Nav_Menu extends Walker_Nav_Menu {
	  function start_lvl(&$output, $depth = 0, $args = array()) {
	    $indent = str_repeat("\t", $depth);
	    $output .= "\n$indent<ul class=\"dl-submenu\">\n";
	  }
	}
}
if(!class_exists('Solien_Custom_Menu_Walker')){
	class Solien_Custom_Menu_Walker extends Walker_Nav_Menu {
		function start_lvl( &$output, $depth = 0, $args = array() ) {
			$ex_li = '';
				$ex_li = "<li class=\"back-to-menu\">".esc_html__('back', 'solien')."</li>";
			$indent = str_repeat( "\t", $depth );
			$output .= "\n{$indent}<ul class=\"sub-menu\">\n".$ex_li;
		}   
	}
}

if(!function_exists('solien_widget_custom_walker')){
	function solien_widget_custom_walker( $args ) {
	    return array_merge( $args, array(
	        'walker' => new Solien_Custom_Menu_Walker(),
	        // another setting go here ... 
	    ) );
	}
	add_filter( 'widget_nav_menu_args', 'solien_widget_custom_walker' );
}
if(!function_exists('solien_embed_wrap')){
	add_filter('embed_oembed_html', 'solien_embed_wrap', 10, 4);
	function solien_embed_wrap($html, $url, $attr, $post_ID) {
	    if (strpos($url, 'youtube') !== false || strpos($url, 'vimeo') !== false ) {
	        $html = '<div class="video-container">'.$html.'</div>';
	    }
	    return $html;
	}
}

if(!function_exists('solien_search_filter')){
	function solien_search_filter($query) {
		if ($query->is_search) {
		$query->set('post_type', 'post');
		}
		return $query;
	}
	add_filter('pre_get_posts','solien_search_filter');
}

if(!function_exists('solien_post_layout_classes')){
	add_filter('body_class', 'solien_post_layout_classes');
	function solien_post_layout_classes($classes) {
		$tmp = rwmb_meta( 'asw_post_layout' );
        if( !is_array($tmp) && $tmp != '' ){
        	$classes[] = 'post-layout-'.$tmp;
        }
        return $classes;
	}
}
if(!function_exists('solien_add_meta_viewport')){
	function solien_add_meta_viewport(){
		if( get_theme_mod('asw_responsiveness', true) ) {
			echo '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">';
		}
	}
	add_action('asw_header_meta', 'solien_add_meta_viewport');
}
if(!function_exists('solien_gallery_post')){
	function solien_gallery_post($postID = false, $echo = true){
		if(!$postID){
			$postID = get_the_ID();
		}
		$out = '';
		$images = rwmb_meta( 'asw_gallery_images', 'type=image&size=large');
		if(!empty($images) && !solien_post_has_more_link( get_the_ID() )){ 
			$out .= '<div class="gallery-block">';
				$i=1;
				foreach( $images as $image ) :  
					if($i > 2) break;
					if( $i == 2 ) {
						$img_id = $image['ID'];
						$tmp_image = wp_get_attachment_image_src($img_id, 'masonry', false);
						$image_url = $tmp_image[0];
					} else {
						$image_url = $image['url']; 
					}
					$out .= '<div class="gallery-image-'.$i.'"><a href="'.esc_url($image['full_url']).'" data-lightbox="lightbox-gallery" data-caption="'.esc_attr($image['caption']).'"><img src="'.esc_url($image_url).'" alt="'.esc_attr($image['alt']).'" /></a></div>';
				$i++;
				endforeach;
			$out .= '</div>';
		} elseif( has_post_thumbnail() && !solien_post_has_more_link( get_the_ID() ) ) {
			$out .= '<figure class="post-img" itemprop="image"><a href="'.esc_url(get_the_permalink()).'" rel="bookmark">'.get_the_post_thumbnail('large').'</a></figure>';
		}
		if($echo){
			echo ''.$out;
		} else {
			return $out;
		}
	}
}
if( !function_exists('solien_shop_loop_columns')){
	add_filter('loop_shop_columns', 'solien_shop_loop_columns');
	function solien_shop_loop_columns() {
		return 3; // 3 products per row
	}
}
	
?>