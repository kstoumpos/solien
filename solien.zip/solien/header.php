<?php global $post; ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<?php do_action('asw_header_meta'); ?>
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<link rel="shortcut icon" href="<?php echo get_theme_mod('asw_media_favicon',get_template_directory_uri().'/favicon.ico'); ?>">
	<link rel="apple-touch-icon" href="<?php echo get_theme_mod('asw_media_favicon',get_template_directory_uri().'/favicon.ico'); ?>">
	<?php wp_head(); ?>
</head>
<?php if( get_theme_mod('asw_progress_indicator', true) ){
	$showProgressIndicator = 'show-progress-indicator';
} else {
	$showProgressIndicator = '';
} ?>
<body <?php body_class(); ?>>
<?php if(get_theme_mod('asw_page_loading', false) == true ){ ?>
	<div class="page-loading">
		<div class="loader">
		    <svg class="circular" viewBox="25 25 50 50">
		      <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"/>
		    </svg>
		</div>
	</div>
<?php } ?>
<div id="main" class="<?php echo esc_attr($showProgressIndicator); ?>">
<?php if(get_theme_mod('asw_progress_indicator', false) == true ){ ?>
	<div class="pie-wrapper" id="pieWrapper">
		<div class="pie-top-button"><i class="fa fa-angle-up"></i></div>
		<div class="pie" id="pieLeft" style="transform: rotate(64.0228deg);"></div>
		<div class="pie hide" id="pieRight"></div>
		<div class="pie pie--right hide" id="pieMask"></div>
		<div class="mask mask--left" id="maskLeft"></div>
    </div>
<?php } ?>
	<div id="header-main" class="<?php if( get_theme_mod('asw_fixed_header', true) ) echo 'fixed_header'; ?>">
	<?php get_template_part('templates/headers/header-version1'); ?>
	</div>
	<div class="logo">
		<?php if(get_theme_mod('asw_media_logo','') != "") { ?>
			<a href="<?php echo esc_url(home_url()); ?>/" class="logo_main"><img src="<?php echo esc_url(get_theme_mod('asw_media_logo')); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" /></a>
		<?php } else { ?>
			<a href="<?php echo esc_url(home_url()); ?>/" class="logo_text"><?php echo esc_attr(get_bloginfo('name')); ?></a>
		<?php } ?>
	</div>
			