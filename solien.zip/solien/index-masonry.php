<?php 
/**
 * Template Name: Page: Masonry Blog
 */
 ?>

<?php get_header(); ?>

<?php 
// Get Blog Layout from Theme Options

if ( is_front_page() ) {
  $paged = (get_query_var('page')) ? get_query_var('page') : 1;
} else {
  $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
}
?>
<div id="page-wrap" class="row masonry-page">
	<div id="posts-masonry-featured" class="span6">
		<?php
		$args = array(
		    'post_type' => 'post',
		    'posts_per_page' => '1',
		    'order'          => 'DESC',
		    'orderby'   => 'rand',
		    'post__not_in' => get_option( 'sticky_posts' ),
		    'post_status'    => 'publish',
		    'paged' => $paged,
		    'meta_query' => array(
		        array(
		         'key' => '_thumbnail_id',
		         'compare' => 'EXISTS'
		        ),
		    )
	    ); 
		query_posts( $args );
		if (have_posts()) : 
			while (have_posts()) : the_post(); ?>
				<div itemscope itemtype="http://schema.org/Article" <?php post_class('post-masonry span12 featured'); ?> role="article">
					<div class="post-content-container aligncenter">
						<?php if( has_post_thumbnail() ) {?>
							<figure class="post-img" itemprop="image"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_post_thumbnail('large'); ?></a></figure>
						<?php } ?>
						<header class="title">
							<div class="meta-categories"><?php echo get_the_category_list(', '); ?></div>
							<h2 itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__('Permalink to %s', 'solien'), the_title_attribute('echo=0') ); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
							<div class="meta-date<?php if (get_theme_mod( 'asw_posts_headings_separator', true ) ) echo ' separator'; ?>"><span><?php echo esc_html__('Posted by', 'solien').' '.get_the_author(); ?></span><time datetime="<?php echo date(DATE_W3C); ?>"><?php echo esc_html__('On', 'solien').' '; the_time(get_option('date_format')); ?></time></div>
						</header>
					</div>
				</div>
			
			<?php
			endwhile;
		endif; ?>
	</div>
	<div id="content" class="span6">
			<?php
			$posts_per_page = get_option('posts_per_page') != '' ? get_option('posts_per_page') : 8 ;
			$args = array(
			    'post_type' => 'post',
			    'posts_per_page' => $posts_per_page,
			    'order'          => 'DESC',
			    'orderby'        => 'date',
			    'post_status'    => 'publish',
			    'paged' => $paged
		    ); 
			query_posts( $args );
			if (have_posts()) : while (have_posts()) : the_post(); ?>
					<div itemscope itemtype="http://schema.org/Article" <?php post_class('post-masonry span6 standard'); ?> role="article">
						<div class="post-content-container aligncenter">
							<?php if( has_post_thumbnail() ) {?>
								<figure class="post-img" itemprop="image"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_post_thumbnail('masonry'); ?></a></figure>
							<?php } ?>
							<div class="meta-categories"><?php echo get_the_category_list(', '); ?></div>
							<header class="title">
								<h3 itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__('Permalink to %s', 'solien'), the_title_attribute('echo=0') ); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
							</header>
							<div class="meta-date<?php if (get_theme_mod( 'asw_posts_headings_separator', true ) ) echo ' separator'; ?>"><span><?php echo esc_html__('Posted by', 'solien').' '.get_the_author(); ?></span><time datetime="<?php echo date(DATE_W3C); ?>"><?php echo esc_html__('On', 'solien').' '; the_time(get_option('date_format')); ?></time></div>
							<?php if (!has_post_thumbnail() && solien_post_has_more_link( get_the_ID() ) ) {
								echo '<div class="post-excerpt">'.solien_get_the_content().'</div>';
							} ?>
						</div>
					</div>
				<?php 
			endwhile;
			else : ?>	
				<h2><?php esc_html_e('Not Found', 'solien') ?></h2>
			<?php endif; ?>
	
	</div>
	<div class="span12" style="display:none;">
		<?php
			get_template_part( 'framework/inc/nav' ); 
			wp_reset_query();
		?>
	</div>
</div>

<?php get_footer(); ?>
