<?php get_header(); ?>

<?php 
// Get Blog Layout from Theme Options
if(get_theme_mod('asw_sidebar_pos', 'sidebar-right') != 'none'){
	$sidebar_pos = get_theme_mod('asw_sidebar_pos', 'sidebar-right').' span9';
} else {
	$sidebar_pos ='span12';
}
if( !is_active_sidebar('blog-widgets') ) {
	$sidebar_pos ='span12';
}
if(get_theme_mod('asw_home_slider', false)) {
?>
<?php
		$post_ids = get_theme_mod('asw_home_slider_posts','');
		if(strlen($post_ids)){
			$post_ids = trim($post_ids);
			$post_ids = explode(',', $post_ids);
			$orderby = 'post__in';
		} else {
			$post_ids = array();
			$orderby = 'date';
		}
		$args = array(
		    'post_type' => 'post',
		    'posts_per_page' => get_theme_mod('asw_home_slides_count','5'),
			'post__in' => $post_ids,
		    'order'          => 'DESC',
		    'orderby'        => $orderby,
		    'post_status'    => 'publish',
		    'post__not_in' => get_option( 'sticky_posts' ),
		    'meta_query' => array(
		        array(
		         'key' => '_thumbnail_id',
		         'compare' => 'EXISTS'
		        )
		    )
	    ); 
	    $out = '';
		query_posts( $args );
		if( have_posts() ) {
			$out .= '<div id="post-slider" class="owl-carousel post-slider post-slider-center fullwidth">';
			while( have_posts() ) {
				the_post();
				$out .= '<div class="post-slider-item">';
					if( has_post_thumbnail() ) {
						$out .= '<figure class="post-img" itemprop="image"><a href="'.get_the_permalink().'" rel="bookmark">'.get_the_post_thumbnail($post->ID, 'solien-slider').'</a></figure>';
					}
					$out .= '<div class="post-more">';
					$out .= '<div class="post-more-inner">';
						$out .= '<h3>'.esc_attr(get_the_title()).'</h3>';
						$out .= '<div class="read-more-hover"><div class="meta-date"><span>'. esc_html__('Posted by', 'solien').' '.get_the_author().' </span><time datetime="'.date(DATE_W3C).'">'. esc_html__('On', 'solien').' '.get_the_time(get_option('date_format')).'</time></div>';
						$out .= '<a href="'.esc_url(get_the_permalink()).'" class="post-more-link" title="'.esc_html__('Permalink to', 'solien').' '.esc_attr(the_title_attribute('echo=0')).'" rel="bookmark">'.esc_html__('Read more', 'solien').'</a></div>';
					$out .= '</div>';
					$out .= '</div>';
				$out .= '</div>';
			}
			$out .= '</div>';
			echo ''.$out;
			wp_reset_query();
		}
	?>

<?php } //end slider output if ?>
<div id="page-wrap-blog" class="container">
	<div id="content" class="<?php echo esc_attr($sidebar_pos); ?>">
		<div class="row">
			<?php if (have_posts()) : 
			while (have_posts()) : 
				
				the_post(); 
				if( is_sticky() ){
					get_template_part('templates/posts/post-sticky');
				} else {
					get_template_part('templates/posts/post-content');
				}

			endwhile;
			
			echo '<div class="clearfix"></div>';
			
			get_template_part( 'framework/inc/nav' ); 
			?>
				
			<?php else : ?>
				
				<h2><?php esc_html_e('Not Found', 'solien') ?></h2>
				
			<?php endif; ?>
		</div>
	</div>

<?php if(get_theme_mod('asw_sidebar_pos', 'sidebar-right') != 'none'){
		get_sidebar();
	} 
?>
</div>

<?php get_footer(); ?>