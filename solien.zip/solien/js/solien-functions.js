(function($) {
    "use strict";
    $.fn.visible = function(partial) {
        var $t        = $(this),
        $w            = $(window),
        viewTop       = $w.scrollTop(),
        viewBottom    = viewTop + $w.height(),
        _top          = $t.offset().top + $t.height()/5,
        _bottom       = _top + $t.height(),
        compareTop    = partial === true ? _bottom : _top,
        compareBottom = partial === true ? _top : _bottom;

        return ((compareBottom <= viewBottom) && (compareTop >= viewTop));
    };
})(jQuery);

function solien_is_mobile(){
    var windowWidth = window.screen.width < window.outerWidth ? window.screen.width : window.outerWidth;
    if(('ontouchstart' in document.documentElement) || windowWidth < 783){
        return true;
    } else {
        return false;
    }
}

function solien_header_size()
{
    var win             = jQuery(window),
        elements        = jQuery('#header .logo img'),
        el_height       = jQuery(elements).width(),
        main            = jQuery('#main'),
        set_height      = function()
        {
            var st = win.scrollTop(), newH = 0, newLH=0;

            if (st < el_height/2) {
                    newH = el_height - st;
            } else {
                newH = el_height/2;
            }
            elements.css({width: newH + 'px'});
            jQuery('#header-main.fixed_header').toggleClass('header-scrolled', win.scrollTop() > 0);
            if (win.scrollTop() > 0 ) {
                newP = jQuery('#header-main.fixed_header').height();
            } else {
                newP = 0;
            }
            main.css({
                paddingTop: newP + 'px'
            });
        }

        if(solien_is_mobile() || !jQuery('#header-main.fixed_header').length) return false;
        win.scroll(set_height);
        set_height();
}
function solien_home_parallax() {
    jQuery(window).scroll(function () {
        var coords, yPos = (jQuery(window).scrollTop() / 2);
        coords = yPos + 'px';
        jQuery('.featured-post-img img').css({
            top: coords
        });

    });
}
function solien_fix_sidebar() {
    var marginTop = jQuery('#header-main').height() + jQuery('#wpadminbar').height()+50;
    jQuery('#sidebar').theiaStickySidebar({
      // Settings
      additionalMarginTop: marginTop
    });
}

jQuery( document ).ready( function($) {
	"use strict";
    solien_fix_sidebar();
    $('body').on('click', 'a[href^="#"]', function(){
        var $href = $(this).attr('href');
        var hash = $href.substring($href.indexOf('#'));
        var elemTo = $(hash);
        
        if(elemTo.length){
            var $anchor = $(hash).offset();
            var headerH = jQuery('#header-main').height() + jQuery('#wpadminbar').height() + 60;
            $('html, body').animate({ scrollTop: $anchor.top-headerH }, 900);
        }
    });
    var win = $(window),
        allMods = $(".post-masonry");
    win.load(function(){
        var isoOptions = {
                itemSelector: '.post-masonry',
                layoutMode: 'masonry',
                masonry: {
                    columnWidth: '.span6'
                },
                percentPosition:true,
            };
        var isoOptionsBlog = {
                    itemSelector: '.post',
                    layoutMode: 'masonry',
                    masonry: {
                        columnWidth: '.span6'
                    },
                    percentPosition:true,
                };
        var $grid = $('.masonry-page #content').isotope(isoOptions);
        var $gridBlog2 = $('#latest-posts .blog-posts');
        $gridBlog2.isotope(isoOptionsBlog);       
        win.resize(function(){
            $grid.isotope('layout');
            $gridBlog2.isotope('layout');
        });
        $gridBlog2.infinitescroll({
            navSelector  : '#pagination',    // selector for the paged navigation 
            nextSelector : '#pagination a.next',  // selector for the NEXT link (to page 2)
            itemSelector : '.post',     // selector for all items you'll retrieve
            loading: {
                finishedMsg: 'No more items to load.',
                msgText: '<i class="fa fa-spinner fa-spin fa-2x"></i>'
              },
            animate      : false,
            errorCallback: function(){
                $('a.loadmore').removeClass('active').hide();
                $('a.loadmore').addClass('hide');
            },
            appendCallback: true
            },  // call Isotope as a callback
            function( newElements ) {
                var newElems = $( newElements ); 
                newElems.imagesLoaded(function(){
                    $gridBlog2.isotope( 'appended', newElems );
                    $gridBlog2.isotope('layout');
                    newElems.fadeIn(); // fade in when ready
                    $('a.loadmore').removeClass('active');
                });
            }
        );
        $('.masonry-page #content').infinitescroll({
            navSelector  : '#pagination',    // selector for the paged navigation 
            nextSelector : '#pagination a.next',  // selector for the NEXT link (to page 2)
            itemSelector : '.post-masonry.standard',     // selector for all items you'll retrieve
            loading: {
                finishedMsg: 'No more items to load.',
                msgText: '<i class="fa fa-spinner fa-spin fa-2x"></i>'
              },
            animate      : false,
            errorCallback: function(){
                
            },
            appendCallback: true
            },  // call Isotope as a callback
            function( newElements ) {
                var newElems = $( newElements ); 
                newElems.imagesLoaded(function(){
                    $('.masonry-page #content').isotope( 'appended', newElems );
                    $('.masonry-page #content').isotope('layout');
                    newElems.each(function(i, el) {
                        var el = $(el);
                        if (el.visible(true)) {
                            el.addClass("already-visible"); 
                        } 
                    });
                    win.scroll(function(event) {
                        newElems.each(function(i, el) {
                            var el = $(el);
                            if (el.visible(true)) {
                                el.addClass("come-in");
                            }
                        });
                    });
                });
            }
        );
        $('a.loadmore').click(function () {
            $(this).addClass('active');
            $gridBlog2.infinitescroll('retrieve');
            return false;
        });
        setTimeout(function(){ $('.page-loading').fadeOut('fast', function (){});}, 100);
    });

    // Already visible modules
    
    allMods.each(function(i, el) {
        var el = $(el);
        if (el.visible(true)) {
            el.addClass("already-visible"); 
        } 
    });
    win.scroll(function(event) {
        allMods.each(function(i, el) {
            var el = $(el);
            if (el.visible(true)) {
                el.addClass("come-in");
            }
        });
    });

    var summaries = $(".post-masonry.featured");
        summaries.each(function(i) {
            var summary = $(summaries[i]);
            var next = summaries[i + 1];
            summary.scrollToFixed({
                marginTop: $('#header-main').outerHeight(true) + $('.logo').outerHeight()/2 + $('#wpadminbar').outerHeight(true),
                limit: function() {
                    var limit = 0;
                    if (next) {
                        limit = $(next).offset().top - $(this).outerHeight(true) - 60;
                    } else {
                        if( $('#before-footer:visible').length ) {
                            limit = $('#before-footer').offset().top - $(this).outerHeight(true) - 60;
                        } else {
                            limit = $('#footer').offset().top - $(this).outerHeight(true) - 60;
                        }
                    }
                    return limit;
                },
                unfixed: function(){
                    
                },
                zIndex: 0,
                removeOffsets:true,
                offsets:false,
                minWidth:780
            });
        });
    function hasValue(elem) {
        $(elem).keypress(function(){$(this).addClass('has-content');});

        if($(elem).filter(function() { return $(this).val(); }).length > 0) {
            $(elem).addClass('has-content');
            return true;
        } else {
            $(elem).removeClass('has-content');
            return false;
        }
    }
    $('.pie-wrapper').click(function () {
        $('html, body').animate({
            scrollTop: 0
        }, '800');
        return false;
    });
    solien_header_size();
    solien_home_parallax();
	$(document).click(function() {
        $("#header .search-link .search-area").fadeOut('fast');
        $("#header-main").css({'paddingRight':'0px'});
        $("body").removeClass("overflow-hidden");
        if(!solien_is_mobile()){
            $("body").removeClass("overflow-hidden");
        }
        $("#header .menu-hidden-container").fadeOut('fast');
        $("#header .menu-hidden-container #hidden-nav").animate({left:'-500px'},300);
        hasValue($('#header-s'));
    });
    $('.widget_nav_menu .menu .menu-item').on("click", function(e){
        var submenu = $(this).children('.sub-menu');
        var parent_submenu = $(this).parent();
        submenu.toggleClass('sub-menu-show'); //then show the current submenu
        if(submenu.hasClass('sub-menu-show')){
            $('.widget_nav_menu .menu').css('height', submenu.height()+'px');
        } else {
            $('.widget_nav_menu .menu').css('height', parent_submenu.height()+'px');
        }
        if(!$('.sub-menu').hasClass('sub-menu-show')){
            $('.widget_nav_menu .menu').css('height', 'auto');
        } else {
        }
        e.stopPropagation();
        e.preventDefault();
    });
    $('.widget_nav_menu .menu .menu-item a').click(function(f){
        f.stopPropagation();
    });
    $('.menu-button-close').click(function(){
    	$("body").removeClass("overflow-hidden");
        $("#header-main").css({'paddingRight':'0px'});
    	$("#header .menu-hidden-container").fadeOut('fast');
        $("#header .menu-hidden-container #hidden-nav").animate({left:'-500px'},300);
    });
	$(".search-link .search-area input, .menu-hidden-container #hidden-nav").click(function (e) {
        e.stopPropagation();
        //do redirect or any other action on the content
    });
    $("#header .search-link a").click(function (e) {
        e.stopPropagation();
        $(this).next().css({'top':$('#header').outerHeight() + $('#wpadminbar').outerHeight()});
        $(this).next().stop().show();
        if ($("body").height() > $(window).height()) {
		    $("body").addClass("overflow-hidden");
		}
        if( $(window).scrollTop() > 0 ) {
            $("#header-main").css({'paddingRight':'17px'});
        }
        hasValue($('#header-s'));
    });
    $("#mobile-nav a.close-button").click(function(){
        $("#mobile-nav > div > div").stop().hide();
        $("body").removeClass("overflow-hidden");
        $("#mobile-nav a.close-button").stop().hide();
        return false;
    });
    $("#mobile-nav .search-link a.search-button, #mobile-nav .social-menu-button a.social-button, #mobile-nav .hidden-menu-button a.menu-button-open").click(
        function () {
           $("#mobile-nav > div > div").stop().hide();
            $("#mobile-nav a.close-button").stop().hide();
            $(this).next().next().stop().show();
            $(this).parent().find('.close-button').stop().show();
            if ($("body").height() > $(window).height()) {
                $("body").addClass("overflow-hidden");
            }
            hasValue($('#header-s'));
        }
    );

    $("#header .menu-button-open").click(function (f) {
        f.stopPropagation();
        $(".search-link .search-area").fadeOut('fast');
        hasValue($('#header-s'));

        $(this).next().stop().fadeIn();
        $(this).next().find('#hidden-nav').animate({left:'0px'},300);
        if ($("body").height() > $(window).height()) {
		    $("body").addClass("overflow-hidden");
		}
        if( $(window).scrollTop() > 0 ) {
            $("#header-main").css({'paddingRight':'17px'});
        }
    });

    var $progressPie = $(this).find('#pieWrapper');
    var isProgressIndicatorOn = $('.show-progress-indicator').length;
    var scrollStopped;

    var fadeInCallback = function () {
        if (typeof scrollStopped != 'undefined') {
            clearInterval(scrollStopped);
        }
        scrollStopped = setTimeout(function () {
            $progressPie.removeClass('show');
        }, 1500);
    };
    $progressPie.hover(function(){
        clearInterval(scrollStopped);
    }, function(){
        scrollStopped = setTimeout(function () {
            $progressPie.removeClass('show');
        }, 1500);
    });
    var init = function () {

    var windowHeight = window.innerHeight;
    var pageLength;
    var distance;
    var pos = 0;
    var rotation = 0;

    if (isProgressIndicatorOn) {
      $(window).on('scroll', function () {
        
        fadeInCallback.call(this);
        $progressPie.addClass('show');

        // Pixel length of the post.
        pageLength = $(this).height();

        // Total distance need to travel to "read" the whole post
        distance = pageLength - windowHeight;
        pos = $(window).scrollTop();

        // Are we to the end of the post yet? No, ok...
        if ((pos / distance) <= 1) {
          // Degrees of rotation
          rotation = (pos / distance) * 360;
          // Less than halfway, rotate the left half into the right side
          if ((pos / distance) < 0.5) {
            $('#pieLeft').css('transform', 'rotate(' + rotation + 'deg)');
            $('#maskLeft').removeClass('hide');
            $('#pieRight').addClass('hide');
            $('#pieMask').addClass('hide');
          // More than halfway, show the whole left half on the right,
          // rotate the right half into the left side.
          } else {
            $('#pieLeft').css('transform', 'rotate(180deg)');
            $('#maskLeft').addClass('hide');
            $('#pieRight').removeClass('hide').css('transform', 'rotate(' + rotation + 'deg)');
            $('#pieMask').removeClass('hide');
          }
        // Post is completely scrolled thru, so show everything.
        } else {
          $('#pieLeft').css('transform', 'rotate(180deg)');
          $('#maskLeft').addClass('hide');
          $('#pieRight').removeClass('hide').css('transform', 'rotate(360deg)');
          $('#pieMask').removeClass('hide');
        }
      }.bind(this));
    }
   }.bind(this);

    init();

    var totalItems = $('.single-post-gallery .owl-item').length;
    var currentIndex = 1;
    $('.num-slides').html('<span>'+currentIndex+'</span>/'+totalItems+'');

    $('.single-post-gallery').on('changed.owl.carousel', function(event) {
        var totalItems = event.item.count;
        var currentIndex = event.item.index + 1;
       $('.num-slides').html('<span>'+currentIndex+'</span>/'+totalItems+'');
    });

    $( 'a[data-lightbox^="lightbox-insta"]' ).lightbox();
    $( 'a[data-lightbox*="lightbox-gallery"]' ).lightbox();
    $( '[id*="gallery"] a').lightbox();

    $('a[href$=jpg], a[href$=JPG], a[href$=jpeg], a[href$=JPEG], a[href$=png], a[href$=gif], a[href$=bmp]:has(img)').not('[data-lightbox*="lightbox"]').each(function(){
        if( !$(this).parent().parent().parent().hasClass('gallery') ){
            $(this).lightbox();
        }
    });

    
    
});