<?php
/*
Template Name: Page: Fullwidth
*/
?>

<?php get_header(); ?>
	<div id="page-wrap">
		<div id="content" <?php post_class(); ?>>
		<div class="container"><?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<?php the_content(); ?>
			
					<?php wp_link_pages(array('before' => 'Pages: ', 'next_or_number' => 'number')); ?>
					
				<?php endwhile; endif; ?></div>
		</div> <!-- end content -->
	</div> <!-- end page-wrap -->
<?php get_footer(); ?>
