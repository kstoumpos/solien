
<?php get_header(); ?>
<?php 
	if( is_active_sidebar('blog-widgets') ) {
		$sidebar_pos ='sidebar-right span9';
	} else {
		$sidebar_pos = 'span12';
	}
?>
<div id="page-wrap" class="container">

	<div id="content" class="<?php echo ''.$sidebar_pos; ?>">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		
			<div class="entry">
				<header class="title">
					<h2><?php echo esc_attr(get_the_title()); ?></h2>
				</header>

				<?php the_content(); ?>

				<?php wp_link_pages(array('before' =>'<div class="pagination_post aligncenter">', 'after'  =>'</div>', 'pagelink' => '<span>%</span>')); ?>

			</div>

		</article>
		<?php comments_template(); ?>
		<?php endwhile; endif; ?>
	</div> <!-- end content -->
	
	<?php if( is_active_sidebar('blog-widgets') ) { get_sidebar(); } ?>
	
</div> <!-- end page-wrap -->
	
<?php get_footer(); ?>
