<?php get_header(); ?>

<?php 
// Get Blog Layout from Theme Options
if(get_theme_mod('asw_sidebar_pos', 'sidebar-right') != 'none'){
	$sidebar_pos = get_theme_mod('asw_sidebar_pos', 'sidebar-right').' span9';
} else {
	$sidebar_pos ='span12';
}
if( !is_active_sidebar('blog-widgets') ) {
	$sidebar_pos = 'span12';
}
?>
<div id="page-wrap-blog" class="container">
	<div id="content" class="<?php echo esc_attr($sidebar_pos); ?>">
		<div class="row-fluid">
			<?php if (have_posts()) : while (have_posts()) : the_post(); 
				
				get_template_part('templates/posts/post-content');
				
			endwhile;
			
			echo '<div class="clearfix"></div>';
			
			get_template_part( 'framework/inc/nav' ); 
			?>
				
			<?php else : ?>

				<header class="title">
					<h2><?php esc_html_e('Not Found', 'solien') ?></h2>
				</header>
				<div class="meta-date<?php if (get_theme_mod( 'asw_posts_headings_separator', true ) ) echo ' separator'; ?>"><span><?php echo esc_html__('Try to change your query', 'solien').' '.get_the_author(); ?></span></div>
						
				
				<form action="<?php echo esc_url(home_url()); ?>/" id="search-not-found" method="get">
			        <p><input type="text" name="s" placeholder="Your search string" autocomplete="off" /></p>
			        <p class="textright">
			        	<button type="submit"><?php esc_html_e('Search', 'solien') ?></button>
			        </p>
				</form>
				
			<?php endif; ?>
		</div>
	</div>

<?php if(get_theme_mod('asw_sidebar_pos', 'sidebar-right') != 'none'){
		get_sidebar();
	} 
?>
</div>

<?php get_footer(); ?>
