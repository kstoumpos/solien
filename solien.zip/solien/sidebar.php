<div id="sidebar" class="span3">
	<?php 
		if ( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar('Blog Widgets') );
	?>
</div>