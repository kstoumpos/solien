<?php get_header(); ?>

<?php 
if(get_theme_mod('asw_shop_sidebar_pos', 'none') != 'none'){
	$sidebar_pos = get_theme_mod('asw_shop_sidebar_pos', 'none').' span9';
} else {
	$sidebar_pos ='span12';
}
?>
<div id="page-wrap-blog" class="container">
	<div id="content" class="<?php echo esc_attr($sidebar_pos); ?> single">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<article itemscope itemtype="http://schema.org/Article" <?php post_class(); ?> role="article">
					<div class="post-content-container">
						<div class="post-content">
							<div class="post-excerpt">
								<?php the_content(); ?>
							</div>
						</div>
					</div>
					<?php 
						if(comments_open()) {
							comments_template();
						} 
					?>
						<div id="post-navigation" class="wrapper ">
							<?php
								$prevPost = get_previous_post();
								$nextPost = get_next_post();	
							?>
							<?php if($prevPost) { $prevURL = get_permalink($prevPost->ID); $image = wp_get_attachment_image_src( get_post_thumbnail_id( $prevPost->ID), 'thumbnail' );?>
							<div class="prev">
								<?php previous_post_link('%link', '<i class="fa fa-angle-left"></i>'); ?>
								<a class="prev-post-label" href="<?php echo esc_url($prevURL); ?>" >
									<?php if( !empty($image) ) echo '<img src="'.$image[0].'" />'; ?>
									<div class="prev-post-title">
										<time datetime="<?php echo date(DATE_W3C); ?>"><?php echo get_the_time('F j', $prevPost->ID); ?></time>
										<h2><?php echo get_the_title($prevPost->ID); ?></h2>
									</div>
								</a>
							</div>
							<?php } ?>
							<?php if($nextPost) { $nextURL = get_permalink($nextPost->ID); $image = wp_get_attachment_image_src( get_post_thumbnail_id( $nextPost->ID), 'thumbnail' ); ?>
							<div class="next">
								<?php next_post_link('%link', '<i class="fa fa-angle-right"></i>'); ?>
								<a class="next-post-label" href="<?php echo esc_url($nextURL); ?>">
									<?php if( !empty($image) ) echo '<img src="'.$image[0].'" />'; ?>
									<div class="next-post-title">
										<time datetime="<?php echo date(DATE_W3C); ?>"><?php echo get_the_time('F j', $nextPost->ID); ?></time>
										<h2><?php echo get_the_title($nextPost->ID); ?></h2>
									</div>
								</a>
							</div>
							<?php } ?>
						</div>
				</article>
				
		<?php endwhile; endif; ?>
	</div>

<?php if( get_theme_mod('asw_shop_sidebar_pos', 'none') != 'none' ){
		get_sidebar();
	} 
?>

</div>

<?php get_footer(); ?>
