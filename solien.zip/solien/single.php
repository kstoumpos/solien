<?php get_header(); ?>

<?php 
	$post_layout = rwmb_meta( 'asw_post_layout' );
	if(is_array($post_layout)){
		$post_layout = '';
	}
	switch ($post_layout) {
		case 'nosidebar':
			get_template_part('templates/posts/single/nosidebar');
			break;
		case 'wide':
			get_template_part('templates/posts/single/wide');
			break;
		case 'fullwidth':
			get_template_part('templates/posts/single/fullwidth');
			break;
		default:
			get_template_part('templates/posts/single/default');
			break;
	}
?>

<?php get_footer(); ?>
