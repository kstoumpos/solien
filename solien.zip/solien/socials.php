<div class="social-icons">
	<ul class="unstyled">
	<?php 
	$output='';
	if(get_theme_mod('asw_social_twitter', '') != "") { 
		$output .= '<li class="social-twitter"><a href="'.esc_url(get_theme_mod('asw_social_twitter', '')).'" target="_blank" title="'. esc_html__( 'Twitter', 'solien').'"><i class="fa fa-twitter"></i></a></li>';
	}
	if(get_theme_mod('asw_social_pinterest', '') != "") { 
		$output .= '<li class="social-pinterest"><a href="'.esc_url(get_theme_mod('asw_social_pinterest', '')).'" target="_blank" title="'. esc_html__( 'Pinterest', 'solien').'"><i class="fa fa-pinterest-p"></i></a></li>';
	}
	if(get_theme_mod('asw_social_facebook', '') != "") { 
		$output .= '<li class="social-facebook"><a href="'.esc_url(get_theme_mod('asw_social_facebook', '')).'" target="_blank" title="'. esc_html__( 'Facebook', 'solien').'"><i class="fa fa-facebook"></i></a></li>';
	}
	if(get_theme_mod('asw_social_vimeo', '') != "") { 
		$output .= '<li class="social-vimeo"><a href="'.esc_url(get_theme_mod('asw_social_vimeo', '')).'" target="_blank" title="'. esc_html__( 'Vimeo', 'solien').'"><i class="fa fa-vimeo"></i></a></li>';
	}	 
	if(get_theme_mod('asw_social_instagram', '') != '') { 
		$output .= '<li class="social-instagram"><a href="'.esc_url(get_theme_mod('asw_social_instagram', '')).'" target="_blank" title="'. esc_html__( 'Instagram', 'solien').'"><i class="fa fa-instagram"></i></a></li>';
	}
	if(get_theme_mod('asw_social_tumblr', '') != "") { 
		$output .= '<li class="social-tumblr"><a href="'.esc_url(get_theme_mod('asw_social_tumblr', '')).'" target="_blank" title="'. esc_html__( 'Tumblr', 'solien').'"><i class="fa fa-tumblr"></i></a></li>';
	}
	if(get_theme_mod('asw_social_google_plus', '') != "") { 
		$output .= '<li class="social-googleplus"><a href="'.esc_url(get_theme_mod('asw_social_google_plus', '')).'" target="_blank" title="'. esc_html__( 'Google plus', 'solien').'"><i class="fa fa-google-plus"></i></a></li>';
	}
	if(get_theme_mod('asw_social_forrst', '') != "") { 
		$output .= '<li class="social-forrst"><a href="'.esc_url(get_theme_mod('asw_social_forrst', '')).'" target="_blank" title="'. esc_html__( 'Forrst', 'solien').'"><i class="fa icon-forrst"></i></a></li>';
	}
	if(get_theme_mod('asw_social_dribbble', '') != "") { 
		$output .= '<li class="social-dribbble"><a href="'.esc_url(get_theme_mod('asw_social_dribbble', '')).'" target="_blank" title="'. esc_html__( 'Dribbble', 'solien').'"><i class="fa fa-dribbble"></i></a></li>';
	}
	if(get_theme_mod('asw_social_flickr', '') != "") { 
		$output .= '<li class="social-flickr"><a href="'.esc_url(get_theme_mod('asw_social_flickr', '')).'" target="_blank" title="'. esc_html__( 'Flickr', 'solien').'"><i class="fa fa-flickr"></i></a></li>';
	}
	if(get_theme_mod('asw_social_linkedin', '') != "") { 
		$output .= '<li class="social-linkedin"><a href="'.esc_url(get_theme_mod('asw_social_linkedin', '')).'" target="_blank" title="'. esc_html__( 'LinkedIn', 'solien').'"><i class="fa fa-linkedin"></i></a></li>';
	}
	if(get_theme_mod('asw_social_skype', '') != "") { 
		$output .= '<li class="social-skype"><a href="skype:'.esc_attr(get_theme_mod('asw_social_skype', '')).'" title="'. esc_html__( 'Skype', 'solien').'"><i class="fa fa-skype"></i></a></li>';
	}
	if(get_theme_mod('asw_social_digg', '') != "") { 
		$output .= '<li class="social-digg"><a href="'.esc_url(get_theme_mod('asw_social_digg', '')).'" target="_blank" title="'. esc_html__( 'Digg', 'solien').'"><i class="fa fa-digg"></i></a></li>';
	}
	if(get_theme_mod('asw_social_yahoo', '') != "") { 
		$output .= '<li class="social-yahoo"><a href="'.esc_url(get_theme_mod('asw_social_yahoo', '')).'" target="_blank" title="'. esc_html__( 'Yahoo', 'solien').'"><i class="fa fa-yahoo"></i></a></li>';
	}
	if(get_theme_mod('asw_social_youtube', '') != "") { 
		$output .= '<li class="social-youtube"><a href="'.esc_url(get_theme_mod('asw_social_youtube', '')).'" target="_blank" title="'. esc_html__( 'YouTube', 'solien').'"><i class="fa fa-youtube"></i></a></li>';
	}
	if(get_theme_mod('asw_social_deviantart', '') != "") { 
		$output .= '<li class="social-deviantart"><a href="'.esc_url(get_theme_mod('asw_social_deviantart', '')).'" target="_blank" title="'. esc_html__( 'DeviantArt', 'solien').'"><i class="fa fa-deviantart"></i></a></li>';
	}
	if(get_theme_mod('asw_social_behance', '') != "") { 
		$output .= '<li class="social-behance"><a href="'.esc_url(get_theme_mod('asw_social_behance', '')).'" target="_blank" title="'. esc_html__( 'Behance', 'solien').'"><i class="fa fa-behance"></i></a></li>';
	}
	if(get_theme_mod('asw_social_paypal', '') != "") { 
		$output .= '<li class="social-paypal"><a href="'.esc_url(get_theme_mod('asw_social_paypal', '')).'" target="_blank" title="'. esc_html__( 'PayPal', 'solien').'"><i class="fa fa-paypal"></i></a></li>';
	}
	if(get_theme_mod('asw_social_delicious', '') != "") { 
		$output .= '<li class="social-delicious"><a href="'.esc_url(get_theme_mod('asw_social_delicious', '')).'" target="_blank" title="'. esc_html__( 'Delicious', 'solien').'"><i class="fa fa-delicious"></i></a></li>';
	}
	if(get_theme_mod('asw_social_rss', false)) { 
		$output .= '<li class="social-rss"><a href="'.esc_url(get_bloginfo('rss2_url')).'" target="_blank" title="'. esc_html__( 'RSS', 'solien').'"><i class="fa fa-rss"></i></a></li>';
	} 
	echo ''.$output;
	?>
	</ul>
</div>