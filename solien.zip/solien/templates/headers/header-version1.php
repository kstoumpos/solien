<header id="header" class="header1 clearfix">
	<div class="<?php echo get_theme_mod('asw_header_grid','container'); ?>">
		<div class="my-table">
			<div class="my-tr">
				<div class="my-td span8">
					<?php $hidden_nav = get_theme_mod('asw_header_hidden_nav', false) ? 'display-on': 'hide'; ?>
					<div class="hidden-menu-button <?php echo ''.$hidden_nav; ?>">
						<a href="javascript:void(0);" class="menu-button-open"><i class="la la-bars"></i></a>
						<div class="menu-hidden-container textleft">
							<nav id="hidden-nav">
								<a href="javascript:void(0);" class="menu-button-close"><i class="la la-close"></i></a>
								<?php if ( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar('Hidden Menu Widgets') ); ?>
							</nav>
						</div>
					</div>
					<?php

					if( has_nav_menu( 'main_navigation' ) ) { ?>
					<nav id="navigation">
						<ul id="nav" class="menu">
							<?php wp_nav_menu(array('theme_location' => 'main_navigation', 'container' => false, 'menu_id' => 'nav', 'items_wrap'=>'%3$s', 'fallback_cb' => false)); ?>
						</ul>
					</nav>
					<?php } ?>
				</div>
				<div class="my-td span4 textright">
					<?php if( class_exists('WooCommerce') ) { 
						$cart_url = wc_get_cart_url();
						?>
						<div class="cart-main menu-item">
							<a class="my-cart-link" href="<?php echo esc_url($cart_url);?>"><i class="la la-shopping-cart"></i></a>
						</div>
					<?php } ?>
					<?php if( get_theme_mod('asw_header_search_button',true) ) { ?>
					<div class="search-link">
						<a href="javascript:void(0);" class="search-button"><i class="la la-search"></i></a>
						<div class="search-area">
								<form action="<?php echo esc_url(home_url()); ?>/" id="header-searchform" method="get">
							        <input type="text" id="header-s" name="s" value="" autocomplete="off" />
							        <label><?php esc_html_e('Search','solien'); ?></label>
								</form>
						</div>
					</div>
					<?php } ?>
					<?php if( get_theme_mod('asw_header_socials',true) && function_exists('solien_get_social_links') ) { echo solien_get_social_links(); } ?>
				</div>
			</div>
		</div>
	</div>
</header>