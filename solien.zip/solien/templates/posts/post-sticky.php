<article itemscope itemtype="http://schema.org/Article" <?php post_class('post span12'); ?> role="article">
	<div class="post-content-container aligncenter">
		<div class="post-content">
			<?php
			if( has_post_thumbnail() && !solien_post_has_more_link( get_the_ID() ) ) {?>
				<figure class="post-img" itemprop="image"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_post_thumbnail('large'); ?></a></figure>
			<?php } ?>
			<div class="header-wrap">
				<div class="header-inner">
					<div class="meta-categories"><?php echo get_the_category_list(', '); ?></div>
					<header class="title">
						<h2 itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__('Permalink to %s', 'solien'), the_title_attribute('echo=0') ); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
					</header>
					<div class="meta-date<?php if (get_theme_mod( 'asw_posts_headings_separator', true ) ) echo ' separator'; ?>"><span><?php echo esc_html__('Posted by', 'solien').' '.get_the_author(); ?></span><time datetime="<?php echo date(DATE_W3C); ?>"><?php echo esc_html__('On', 'solien').' '; the_time(get_option('date_format')); ?></time></div>
				</div>
			</div>
			<?php wp_link_pages(array('before' =>'<div class="pagination_post">', 'after'  =>'</div>', 'pagelink' => '<span>%</span>')); ?>
		</div>
		<div class="border-bottom"></div>
	</div>
</article>