<div class="fullwidth-image">
			<?php
				$out = '';
				if( rwmb_meta( 'asw_gallery_layout' ) ){
					$images = rwmb_meta( 'asw_gallery_images', 'type=image&size=fullwidth-slider');
					if ( !empty($images) ){
						$out = '<div class="single-post-gallery">';
						foreach( $images as $image ) :
							$out .= '<div><a href="'.esc_url($image['full_url']).'" data-lightbox="lightbox-gallery" data-caption="'.esc_attr($image['caption']).'"><img src="'.esc_url($image['url']).'" alt="'.esc_attr($image['alt']).'" /></a></div>';
						endforeach;
						$out .= '</div>';
					}
				} else {
					$images = rwmb_meta( 'asw_gallery_images', 'type=image&size=large');
					if ( !empty($images) ){
						$out = '<div class="masonry-wrap">';
							foreach( $images as $image ) :
								$out .= '<div class="masonry-brick"><a href="'.esc_url($image['full_url']).'" data-lightbox="lightbox-gallery" data-caption="'.esc_attr($image['caption']).'"><img src="'.esc_url($image['url']).'" alt="'.esc_attr($image['alt']).'" /></a></div>';
							endforeach;
						$out .= '</div>';
					}
				}
				if($out != ''){
					echo ''.$out;
				} else {
					if( has_post_thumbnail() && !solien_post_has_more_link( get_the_ID() ) ) {
						echo '<figure class="post-img" itemprop="image">';
						the_post_thumbnail('fullwidth-slider');
						echo '</figure>';
					}
				}
				
			?>
</div>
<?php 
if(!is_array( rwmb_meta( 'asw_post_sidebar' ) ) ){
	if( rwmb_meta( 'asw_post_sidebar' ) == '' ){
		$solien_post_sidebar = 'default';
	} else {
		$solien_post_sidebar = rwmb_meta( 'asw_post_sidebar' );
	}
} else {
	$solien_post_sidebar = 'default';
}

if( $solien_post_sidebar == 'none' ){
	$sidebar_pos ='span12';
} elseif( $solien_post_sidebar != 'none' && $solien_post_sidebar != 'default'){
	$sidebar_pos = $solien_post_sidebar;
} elseif (get_theme_mod('asw_sidebar_pos', 'sidebar-right') != 'none'){
	$sidebar_pos = get_theme_mod('asw_sidebar_pos', 'sidebar-right').' span9';
} else {
	$sidebar_pos ='span12';
}

?>
<div id="page-wrap-blog" class="container">
	<div id="content" class="<?php echo esc_attr($sidebar_pos); ?> single">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<article itemscope itemtype="http://schema.org/Article" <?php post_class(); ?> role="article">
					<div class="post-content-container">
						<div class="meta-categories"><?php echo get_the_category_list(', '); ?></div>
						<header class="title">
							<h2 itemprop="headline"><?php the_title(); ?></h2>
						</header>
						<div class="meta-date<?php if (get_theme_mod( 'asw_posts_headings_separator', true ) ) echo ' separator'; ?>"><span><?php echo esc_html__('Posted by', 'solien').' '.get_the_author(); ?></span><time datetime="<?php echo date(DATE_W3C); ?>"><?php the_time(get_option('date_format')); ?></time></div>
						<div class="post-content">
							<div class="post-excerpt">
								<?php the_content(); ?>
							</div>
						</div>
						<div class="post-meta-tags"><span class="meta-tags"><?php the_tags('<i class="fa fa-tags"></i>',', ', ''); ?></span></div>
						<div class="post-meta"><?php get_template_part( 'framework/inc/meta', 'single' ); ?></div>
					</div>
					<?php 
						if ( '' !== get_the_author_meta( 'description' ) ) {
							get_template_part( 'templates/posts/biography' );
						}
						get_template_part( 'templates/posts/related-posts' );
						if(comments_open()) {
							comments_template();
						} 
					?>
						<div id="post-navigation" class="wrapper ">
							<?php
								$prevPost = get_previous_post(true);
								$nextPost = get_next_post(true);	
							?>
							<?php if($prevPost) { $prevURL = get_permalink($prevPost->ID); ?>
							<div class="prev">
								<?php previous_post_link('%link', '<i class="la la-angle-left"></i>'); ?>
								<a class="prev-post-label" href="<?php echo esc_url($prevURL); ?>" >
									<?php if(has_post_thumbnail($prevPost->ID) ) echo get_the_post_thumbnail($prevPost->ID, 'thumbnail'); ?>
									<div class="prev-post-title">
										<time datetime="<?php echo date(DATE_W3C); ?>"><?php echo get_the_time('F j', $prevPost->ID); ?></time>
										<h2><?php echo get_the_title($prevPost->ID); ?></h2>
									</div>
								</a>
							</div>
							<?php } ?>
							<?php if($nextPost) { $nextURL = get_permalink($nextPost->ID); ?>
							<div class="next">
								<?php next_post_link('%link', '<i class="la la-angle-right"></i>'); ?>
								<a class="next-post-label" href="<?php echo esc_url($nextURL); ?>">
									<?php if(has_post_thumbnail($nextPost->ID) ) echo get_the_post_thumbnail($nextPost->ID, 'thumbnail'); ?>
									<div class="next-post-title">
										<time datetime="<?php echo date(DATE_W3C); ?>"><?php echo get_the_time('F j', $nextPost->ID); ?></time>
										<h2><?php echo get_the_title($nextPost->ID); ?></h2>
									</div>
								</a>
							</div>
							<?php } ?>
						</div>
				</article>
				
		<?php endwhile; endif; ?>
	</div>

<?php 
	if( rwmb_meta( 'asw_post_sidebar' ) != 'none' && rwmb_meta( 'asw_post_sidebar' ) != 'default' ){
		get_sidebar();
	} elseif(  rwmb_meta( 'asw_post_sidebar' ) == 'default' && get_theme_mod('asw_sidebar_pos', 'sidebar-right') != 'none' ){
		get_sidebar();
	}
?>
</div>
