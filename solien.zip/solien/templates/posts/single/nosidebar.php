<div id="page-wrap-blog" class="container">
	<div id="content" class="span12 single">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<article itemscope itemtype="http://schema.org/Article" <?php post_class(); ?> role="article">
					<div class="post-content-container">
						<div class="meta-categories"><?php echo get_the_category_list(', '); ?></div>
						<header class="title">
							<h2 itemprop="headline"><?php the_title(); ?></h2>
						</header>
						<div class="meta-date<?php if (get_theme_mod( 'asw_posts_headings_separator', true ) ) echo ' separator'; ?>"><time datetime="<?php echo date(DATE_W3C); ?>"><?php the_time(get_option('date_format')); ?></time></div>
						<div class="post-content">
							<?php
								$out = '';
								if( rwmb_meta( 'asw_gallery_layout' ) ){
									$images = rwmb_meta( 'asw_gallery_images', 'type=image&size=large');
									if ( !empty($images) ){
										$out = '<div class="single-post-gallery">';
										foreach( $images as $image ) :
											$out .= '<div><a href="'.esc_url($image['full_url']).'" data-lightbox="lightbox-gallery" data-caption="'.esc_attr($image['caption']).'"><img src="'.esc_url($image['url']).'" alt="'.esc_attr($image['alt']).'" /></a></div>';
										endforeach;
										$out .= '</div>';
									}
								} else {
									$images = rwmb_meta( 'asw_gallery_images', 'type=image&size=large');
									if ( !empty($images) ){
										$out = '<div class="masonry-wrap">';
											foreach( $images as $image ) :
												$out .= '<div class="masonry-brick"><a href="'.esc_url($image['full_url']).'" data-lightbox="lightbox-gallery" data-caption="'.esc_attr($image['caption']).'"><img src="'.esc_url($image['url']).'" alt="'.esc_attr($image['alt']).'" /></a></div>';
											endforeach;
										$out .= '</div>';
									}
								}
								if($out == ''){
									if( has_post_thumbnail() ) {?>
										<figure class="post-img" itemprop="image"><?php the_post_thumbnail('large'); ?></figure>
									<?php }
								} else {
									echo ''.$out;
								}
							?>
							<div class="post-excerpt">
								<?php the_content(); ?>
							</div>
						</div>
						<div class="post-meta-tags"><span class="meta-tags"><?php the_tags('<i class="fa fa-tags"></i>',', ', ''); ?></span></div>
						<div class="post-meta"><?php get_template_part( 'framework/inc/meta', 'single' ); ?></div>
					</div>
					<?php 
						if ( '' !== get_the_author_meta( 'description' ) ) {
							get_template_part( 'templates/posts/biography' );
						}
						get_template_part( 'templates/posts/related-posts' );
						if(comments_open()) {
							comments_template();
						} 
					?>
						<div id="post-navigation" class="wrapper ">
							<?php
								$prevPost = get_previous_post(true);
								$nextPost = get_next_post(true);	
							?>
							<?php if($prevPost) { $prevURL = get_permalink($prevPost->ID); ?>
							<div class="prev">
								<?php previous_post_link('%link', '<i class="la la-angle-left"></i>'); ?>
								<a class="prev-post-label" href="<?php echo esc_url($prevURL); ?>" >
									<?php if(has_post_thumbnail($prevPost->ID) ) echo get_the_post_thumbnail($prevPost->ID, 'thumbnail'); ?>
									<div class="prev-post-title">
										<time datetime="<?php echo date(DATE_W3C); ?>"><?php echo get_the_time('F j', $prevPost->ID); ?></time>
										<h2><?php echo get_the_title($prevPost->ID); ?></h2>
									</div>
								</a>
							</div>
							<?php } ?>
							<?php if($nextPost) { $nextURL = get_permalink($nextPost->ID); ?>
							<div class="next">
								<?php next_post_link('%link', '<i class="la la-angle-right"></i>'); ?>
								<a class="next-post-label" href="<?php echo esc_url($nextURL); ?>">
									<?php if(has_post_thumbnail($nextPost->ID) ) echo get_the_post_thumbnail($nextPost->ID, 'thumbnail'); ?>
									<div class="next-post-title">
										<time datetime="<?php echo date(DATE_W3C); ?>"><?php echo get_the_time('F j', $nextPost->ID); ?></time>
										<h2><?php echo get_the_title($nextPost->ID); ?></h2>
									</div>
								</a>
							</div>
							<?php } ?>
						</div>
				</article>
				
		<?php endwhile; endif; ?>
	</div>
</div>
